extends CanvasLayer
## All UI: HUD, ability bar, main menu, pause, game over, popups and post-fx.

signal play_pressed
signal retry_pressed
signal menu_pressed
signal resume_pressed
signal quit_pressed
signal track_changed(dir: int)
signal revive_pressed
signal char_changed(dir: int)

const PINK := Color(1.0, 0.35, 0.75)
const CYAN := Color(0.35, 0.9, 1.0)
const GOLD := Color(1.0, 0.8, 0.25)
const PANEL_BG := Color(0.1, 0.05, 0.2, 0.72)
const TEXT_DIM := Color(0.82, 0.74, 0.96)
const POSTFX := preload("res://shaders/postfx.gdshader")

var root: Control
var hud: Control
var menu: Control
var pause_panel: Control
var over: Control
var post_mat: ShaderMaterial
var font: SystemFont

var score_lbl: Label
var dist_lbl: Label
var mult_lbl: Label
var mult_chip: PanelContainer
var gold_lbl: Label
var speed_lbl: Label
var speed_bar: Bar
var energy_bar: Bar
var slots: Array = []
var slot_names: Array = []
var popups: VBoxContainer
var menu_best: Label
var controls_panel: Control
var controls_btn: Button
var track_name: Label
var char_name: Label
var char_hobby: Label
var track_num: Label
var over_title: Label
var over_reason: Label
var over_vals: Dictionary = {}
var over_badge: PanelContainer
var over_revive: Button
var title_box: Control
var gold_icon: CoinIcon
var cores_icon: CoresIcon
var markers_layer: MarkerLayer
var prompt_lbl: Label
var zone_box: VBoxContainer
var zone_title: Label
var zone_sub: Label

var _flash := 0.0
var _flash_color := Color.WHITE
var _gold_pop := 0.0
var _t := 0.0
var _last_mult := 1


# ============================================================ custom widgets
class CoinIcon extends Control:
	var pop := 0.0
	func _draw() -> void:
		var c := size * 0.5
		var r := minf(size.x, size.y) * 0.5 * (1.0 + pop * 0.3)
		draw_circle(c, r, Color(0.85, 0.5, 0.05))
		draw_circle(c, r * 0.82, Color(1.0, 0.8, 0.25))
		draw_arc(c, r * 0.55, 0, TAU, 32, Color(1, 0.95, 0.6), 3.0, true)
		draw_rect(Rect2(c - Vector2(r * 0.12, r * 0.35), Vector2(r * 0.24, r * 0.7)), Color(0.9, 0.55, 0.05))


class CoresIcon extends Control:
	var cores: Array = []
	var fnt: Font
	func _draw() -> void:
		var cols := {"shield": Color(0.35, 0.9, 1.0), "surge": Color(1.0, 0.35, 0.75), "gold": Color(1.0, 0.8, 0.25)}
		if fnt:
			draw_string(fnt, Vector2(0, size.y * 0.5 + 6), "CORES", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(0.82, 0.74, 0.96))
		for i in 3:
			var c := Vector2(76 + i * 26, size.y * 0.5)
			draw_circle(c, 10, Color(0.06, 0.03, 0.12, 0.85))
			if i < cores.size():
				var col: Color = cols[cores[i]]
				draw_circle(c, 11, Color(col, 0.3))
				draw_circle(c, 7, col)
			draw_arc(c, 10, 0, TAU, 20, Color(1, 1, 1, 0.35), 1.5, true)


class MarkerLayer extends Control:
	var markers: Array = []
	var fnt: Font
	var t := 0.0
	func _draw() -> void:
		for m in markers:
			var p: Vector2 = m["pos"]
			var col: Color = m["color"]
			var r := 34.0 if m["big"] else 22.0
			r *= 1.0 + sin(t * 8.0) * 0.08
			for k in 4:
				var a0 := t * 2.0 + k * PI / 2.0
				draw_arc(p, r, a0, a0 + 0.9, 10, col, 4.0 if m["big"] else 3.0, true)
			draw_circle(p, 4.0, col)
			if fnt:
				var fs := 20 if m["big"] else 15
				var tp := p + Vector2(-220, r + fs + 6)
				draw_string_outline(fnt, tp, m["text"], HORIZONTAL_ALIGNMENT_CENTER, 440, fs, 6, Color(0.05, 0.02, 0.1))
				draw_string(fnt, tp, m["text"], HORIZONTAL_ALIGNMENT_CENTER, 440, fs, col)


class Bar extends Control:
	var value := 0.0
	var col_a := Color(1.0, 0.35, 0.75)
	var col_b := Color(0.35, 0.9, 1.0)
	var text := ""
	var fnt: Font
	var glow := 0.0
	func _draw() -> void:
		var bg := StyleBoxFlat.new()
		bg.bg_color = Color(0.06, 0.03, 0.12, 0.8)
		bg.set_corner_radius_all(int(size.y * 0.5))
		bg.border_color = Color(col_a, 0.5 + glow * 0.5)
		bg.set_border_width_all(2)
		draw_style_box(bg, Rect2(Vector2.ZERO, size))
		var w := (size.x - 6.0) * clampf(value, 0.0, 1.0)
		if w > 4.0:
			var steps := 24
			var h := size.y - 6.0
			for i in steps:
				var x0 := 3.0 + w * i / steps
				var x1 := 3.0 + w * (i + 1) / steps
				var c := col_a.lerp(col_b, float(i) / steps)
				draw_rect(Rect2(Vector2(x0, 3.0), Vector2(x1 - x0 + 0.5, h)), c)
			draw_rect(Rect2(Vector2(3.0, 3.0), Vector2(w, h * 0.35)), Color(1, 1, 1, 0.25))
		if text != "" and fnt:
			var fs := int(size.y * 0.62)
			draw_string_outline(fnt, Vector2(0, size.y * 0.5 + fs * 0.36), text, HORIZONTAL_ALIGNMENT_CENTER, size.x, fs, 5, Color(0.05, 0.02, 0.1))
			draw_string(fnt, Vector2(0, size.y * 0.5 + fs * 0.36), text, HORIZONTAL_ALIGNMENT_CENTER, size.x, fs, Color.WHITE)


class AbilitySlot extends Control:
	var id := ""
	var key := ""
	var col := Color.WHITE
	var cd_ratio := 0.0
	var cd_left := 0.0
	var active_ratio := 0.0
	var is_ready := true
	var bump := 0.0
	var deny := 0.0
	var fnt: Font

	func _draw() -> void:
		var c := size * 0.5 + Vector2(sin(deny * 40.0) * deny * 8.0, 0)
		var r := minf(size.x, size.y) * 0.5 - 6.0
		r *= 1.0 + bump * 0.12
		# glow when is_ready or active
		if is_ready or active_ratio > 0.0:
			draw_circle(c, r + 5.0, Color(col, 0.18 + bump * 0.3))
		draw_circle(c, r, Color(0.08, 0.04, 0.16, 0.92))
		draw_arc(c, r, 0, TAU, 64, Color(col, 0.35 if not is_ready else 0.9), 3.0, true)
		var icol := col if (is_ready or active_ratio > 0.0) else Color(0.55, 0.5, 0.65)
		_icon(c, r * 0.5, icol)
		if active_ratio > 0.0:
			draw_arc(c, r - 1.0, -PI / 2, -PI / 2 + TAU * active_ratio, 64, col, 6.0, true)
		if cd_ratio > 0.0:
			var pts := PackedVector2Array([c])
			var seg := 40
			for i in seg + 1:
				var a := -PI / 2 + TAU * cd_ratio * float(i) / seg
				pts.append(c + Vector2(cos(a), sin(a)) * r)
			draw_colored_polygon(pts, Color(0.02, 0.0, 0.06, 0.62))
			if fnt:
				var txt := "%d" % ceili(cd_left)
				draw_string_outline(fnt, Vector2(c.x - 40, c.y + 12), txt, HORIZONTAL_ALIGNMENT_CENTER, 80, 32, 6, Color(0, 0, 0))
				draw_string(fnt, Vector2(c.x - 40, c.y + 12), txt, HORIZONTAL_ALIGNMENT_CENTER, 80, 32, Color.WHITE)
		# key badge
		if fnt:
			var kw := maxf(34.0, key.length() * 13.0 + 16.0)
			var kr := Rect2(Vector2(c.x - kw * 0.5, size.y - 22.0), Vector2(kw, 24))
			var sb := StyleBoxFlat.new()
			sb.bg_color = col if is_ready else Color(0.3, 0.26, 0.4)
			sb.set_corner_radius_all(8)
			draw_style_box(sb, kr)
			draw_string(fnt, Vector2(kr.position.x, kr.position.y + 18), key, HORIZONTAL_ALIGNMENT_CENTER, kw, 16, Color(0.06, 0.02, 0.12))

	func _icon(c: Vector2, s: float, k: Color) -> void:
		var w := 4.0
		match id:
			"dash":
				for o in [-0.45, 0.25]:
					draw_polyline(PackedVector2Array([c + Vector2(o * s - 0.3 * s, -0.6 * s), c + Vector2(o * s + 0.35 * s, 0), c + Vector2(o * s - 0.3 * s, 0.6 * s)]), k, w + 1.0, true)
			"airdash":
				draw_polyline(PackedVector2Array([c + Vector2(-0.6 * s, 0.5 * s), c + Vector2(0.1 * s, -0.2 * s), c + Vector2(0.1 * s, 0.25 * s), c + Vector2(0.7 * s, -0.5 * s)]), k, w + 1.0, true)
				draw_line(c + Vector2(0.7 * s, -0.5 * s), c + Vector2(0.3 * s, -0.5 * s), k, w, true)
				draw_line(c + Vector2(0.7 * s, -0.5 * s), c + Vector2(0.7 * s, -0.1 * s), k, w, true)
				draw_line(c + Vector2(-0.7 * s, 0.75 * s), c + Vector2(0.4 * s, 0.75 * s), Color(k, 0.5), w * 0.7, true)
			"wallrun":
				draw_line(c + Vector2(-0.75 * s, -0.8 * s), c + Vector2(-0.75 * s, 0.8 * s), k, w * 1.6, true)
				for yy in [-0.4, 0.1, 0.6]:
					draw_polyline(PackedVector2Array([c + Vector2(-0.3 * s, (yy - 0.25) * s), c + Vector2(0.2 * s, yy * s), c + Vector2(-0.3 * s, (yy + 0.25) * s)]), k, w, true)
				draw_line(c + Vector2(0.45 * s, 0.7 * s), c + Vector2(0.45 * s, -0.7 * s), Color(k, 0.6), w, true)
			"grapple":
				draw_arc(c + Vector2(0.1 * s, 0.2 * s), 0.45 * s, 0.2, PI + 0.6, 20, k, w + 1.0, true)
				draw_line(c + Vector2(0.55 * s, 0.25 * s), c + Vector2(0.55 * s, -0.75 * s), k, w + 1.0, true)
				draw_circle(c + Vector2(0.55 * s, -0.8 * s), w * 1.5, k)
				draw_line(c + Vector2(-0.35 * s, 0.3 * s), c + Vector2(-0.55 * s, 0.05 * s), k, w, true)
			"timeshift":
				draw_arc(c, 0.75 * s, 0, TAU, 32, k, w, true)
				draw_line(c, c + Vector2(0, -0.5 * s), k, w, true)
				draw_line(c, c + Vector2(0.4 * s, 0.15 * s), k, w, true)
				draw_arc(c, 0.95 * s, -2.4, -0.8, 12, Color(k, 0.5), w * 0.7, true)
				draw_circle(c, w, k)
			"phase":
				for i in 12:
					var a0 := TAU * i / 12.0
					draw_arc(c, 0.75 * s, a0, a0 + 0.3, 4, k, w, true)
				draw_circle(c + Vector2(-0.22 * s, -0.1 * s), w * 1.2, k)
				draw_circle(c + Vector2(0.22 * s, -0.1 * s), w * 1.2, k)
				draw_arc(c + Vector2(0, 0.15 * s), 0.25 * s, 0.3, PI - 0.3, 10, k, w * 0.8, true)
			"magnet":
				draw_arc(c + Vector2(0, 0.05 * s), 0.55 * s, 0, PI, 24, k, w * 2.2, true)
				draw_line(c + Vector2(-0.55 * s, 0.05 * s), c + Vector2(-0.55 * s, -0.6 * s), k, w * 2.2)
				draw_line(c + Vector2(0.55 * s, 0.05 * s), c + Vector2(0.55 * s, -0.6 * s), k, w * 2.2)
				draw_line(c + Vector2(-0.55 * s, -0.4 * s), c + Vector2(-0.55 * s, -0.7 * s), Color.WHITE, w * 2.2)
				draw_line(c + Vector2(0.55 * s, -0.4 * s), c + Vector2(0.55 * s, -0.7 * s), Color.WHITE, w * 2.2)
			"slam":
				draw_line(c + Vector2(0, -0.8 * s), c + Vector2(0, 0.25 * s), k, w * 1.4, true)
				draw_polyline(PackedVector2Array([c + Vector2(-0.35 * s, -0.05 * s), c + Vector2(0, 0.35 * s), c + Vector2(0.35 * s, -0.05 * s)]), k, w * 1.4, true)
				draw_line(c + Vector2(-0.8 * s, 0.7 * s), c + Vector2(0.8 * s, 0.7 * s), k, w * 1.4, true)
				draw_line(c + Vector2(-0.75 * s, 0.45 * s), c + Vector2(-0.5 * s, 0.6 * s), Color(k, 0.7), w, true)
				draw_line(c + Vector2(0.75 * s, 0.45 * s), c + Vector2(0.5 * s, 0.6 * s), Color(k, 0.7), w, true)


# ============================================================ build
func _ready() -> void:
	layer = 5
	process_mode = Node.PROCESS_MODE_ALWAYS
	font = SystemFont.new()
	font.font_names = PackedStringArray(["Montserrat", "Poppins", "Segoe UI", "Arial", "Noto Sans", "DejaVu Sans"])
	font.font_weight = 800

	# post-process layer (beneath the UI)
	var post_layer := CanvasLayer.new()
	post_layer.layer = 1
	add_child(post_layer)
	var post := ColorRect.new()
	post.set_anchors_preset(Control.PRESET_FULL_RECT)
	post.mouse_filter = Control.MOUSE_FILTER_IGNORE
	post_mat = ShaderMaterial.new()
	post_mat.shader = POSTFX
	post.material = post_mat
	post_layer.add_child(post)

	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var th := Theme.new()
	th.default_font = font
	th.default_font_size = 26
	root.theme = th
	add_child(root)

	_build_hud()
	_build_menu()
	_build_pause()
	_build_over()


func _style(bg: Color, border := Color(0, 0, 0, 0), bw := 0, radius := 18, shadow := true) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.content_margin_left = 24
	s.content_margin_right = 24
	s.content_margin_top = 14
	s.content_margin_bottom = 14
	s.anti_aliasing = true
	if shadow:
		s.shadow_color = Color(0.05, 0.0, 0.1, 0.45)
		s.shadow_size = 14
		s.shadow_offset = Vector2(0, 5)
	return s


func _label(text: String, size: int, color := Color.WHITE, outline := 8) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if outline > 0:
		l.add_theme_constant_override("outline_size", outline)
		l.add_theme_color_override("font_outline_color", Color(0.08, 0.02, 0.15))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _panel(bg := PANEL_BG, border := Color(1, 0.4, 0.8, 0.35)) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _style(bg, border, 2, 20))
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return p


func _button(text: String, col: Color, min_w := 320.0) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(min_w, 68)
	b.add_theme_font_size_override("font_size", 28)
	var n := _style(Color(0.12, 0.06, 0.24, 0.92), col, 3, 16)
	var h := _style(Color(col.r * 0.45, col.g * 0.3, col.b * 0.55, 0.95), col.lightened(0.3), 3, 16)
	var p := _style(col.darkened(0.2), Color.WHITE, 3, 16)
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", h)
	b.add_theme_stylebox_override("pressed", p)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color(0.05, 0.02, 0.1))
	b.mouse_entered.connect(func(): b.pivot_offset = b.size * 0.5; create_tween().tween_property(b, "scale", Vector2(1.05, 1.05), 0.1))
	b.mouse_exited.connect(func(): create_tween().tween_property(b, "scale", Vector2.ONE, 0.1))
	return b


func _chip(text: String, col := Color(0.95, 0.9, 1.0)) -> PanelContainer:
	var p := PanelContainer.new()
	var s := _style(col, Color(0, 0, 0, 0), 0, 8, false)
	s.content_margin_left = 10
	s.content_margin_right = 10
	s.content_margin_top = 2
	s.content_margin_bottom = 2
	p.add_theme_stylebox_override("panel", s)
	var l := _label(text, 18, Color(0.08, 0.03, 0.15), 0)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	p.add_child(l)
	p.custom_minimum_size = Vector2(54, 0)
	return p


func _build_hud() -> void:
	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud)

	# score (top-left)
	var sp := _panel()
	sp.position = Vector2(36, 30)
	hud.add_child(sp)
	var sv := VBoxContainer.new()
	sv.add_theme_constant_override("separation", -4)
	sp.add_child(sv)
	sv.add_child(_label("SCORE", 18, TEXT_DIM, 0))
	score_lbl = _label("0", 60, Color.WHITE, 10)
	score_lbl.custom_minimum_size = Vector2(300, 0)
	sv.add_child(score_lbl)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	sv.add_child(row)
	dist_lbl = _label("0 m", 24, CYAN, 0)
	row.add_child(dist_lbl)
	mult_chip = _chip("x1", GOLD)
	mult_lbl = mult_chip.get_child(0)
	row.add_child(mult_chip)

	# gold (top-right)
	var gp := _panel(PANEL_BG, Color(1, 0.8, 0.3, 0.45))
	gp.anchor_left = 1.0
	gp.anchor_right = 1.0
	gp.offset_left = -36
	gp.offset_right = -36
	gp.offset_top = 30
	gp.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	hud.add_child(gp)
	var gh := HBoxContainer.new()
	gh.add_theme_constant_override("separation", 14)
	gp.add_child(gh)
	gold_icon = CoinIcon.new()
	gold_icon.custom_minimum_size = Vector2(52, 52)
	gh.add_child(gold_icon)
	gold_lbl = _label("0", 52, GOLD, 10)
	gold_lbl.custom_minimum_size = Vector2(120, 0)
	gold_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	gh.add_child(gold_lbl)

	# speed (top-center)
	var spd := VBoxContainer.new()
	spd.anchor_left = 0.5
	spd.anchor_right = 0.5
	spd.offset_top = 34
	spd.grow_horizontal = Control.GROW_DIRECTION_BOTH
	spd.alignment = BoxContainer.ALIGNMENT_CENTER
	hud.add_child(spd)
	speed_lbl = _label("0 KM/H", 26, Color.WHITE, 8)
	speed_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	spd.add_child(speed_lbl)
	speed_bar = Bar.new()
	speed_bar.custom_minimum_size = Vector2(260, 12)
	speed_bar.col_a = CYAN
	speed_bar.col_b = PINK
	spd.add_child(speed_bar)

	# popups
	popups = VBoxContainer.new()
	popups.anchor_left = 0.5
	popups.anchor_right = 0.5
	popups.offset_top = 150
	popups.grow_horizontal = Control.GROW_DIRECTION_BOTH
	popups.alignment = BoxContainer.ALIGNMENT_BEGIN
	popups.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(popups)

	# ability bar (bottom-center)
	var bottom := VBoxContainer.new()
	bottom.anchor_left = 0.5
	bottom.anchor_right = 0.5
	bottom.anchor_top = 1.0
	bottom.anchor_bottom = 1.0
	bottom.offset_bottom = -26
	bottom.grow_horizontal = Control.GROW_DIRECTION_BOTH
	bottom.grow_vertical = Control.GROW_DIRECTION_BEGIN
	bottom.add_theme_constant_override("separation", 12)
	bottom.alignment = BoxContainer.ALIGNMENT_CENTER
	hud.add_child(bottom)
	var top_row := HBoxContainer.new()
	top_row.add_theme_constant_override("separation", 18)
	top_row.alignment = BoxContainer.ALIGNMENT_CENTER
	bottom.add_child(top_row)
	cores_icon = CoresIcon.new()
	cores_icon.custom_minimum_size = Vector2(150, 30)
	cores_icon.fnt = font
	top_row.add_child(cores_icon)
	energy_bar = Bar.new()
	energy_bar.custom_minimum_size = Vector2(640, 26)
	energy_bar.col_a = Color(0.6, 0.45, 1.0)
	energy_bar.col_b = PINK
	energy_bar.fnt = font
	top_row.add_child(energy_bar)
	var bar_panel := _panel(Color(0.08, 0.04, 0.16, 0.6), Color(0.6, 0.5, 1.0, 0.3))
	bottom.add_child(bar_panel)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	bar_panel.add_child(hb)
	slots.clear()
	slot_names.clear()

	markers_layer = MarkerLayer.new()
	markers_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	markers_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	markers_layer.fnt = font
	hud.add_child(markers_layer)
	hud.move_child(markers_layer, 0)

	prompt_lbl = _label("", 24, Color.WHITE, 8)
	prompt_lbl.anchor_left = 0.5
	prompt_lbl.anchor_right = 0.5
	prompt_lbl.anchor_top = 1.0
	prompt_lbl.anchor_bottom = 1.0
	prompt_lbl.offset_top = -250
	prompt_lbl.grow_horizontal = Control.GROW_DIRECTION_BOTH
	prompt_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud.add_child(prompt_lbl)

	zone_box = VBoxContainer.new()
	zone_box.anchor_left = 0.5
	zone_box.anchor_right = 0.5
	zone_box.anchor_top = 0.3
	zone_box.anchor_bottom = 0.3
	zone_box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	zone_box.add_theme_constant_override("separation", -10)
	zone_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(zone_box)
	zone_sub = _label("ZONE 2", 26, CYAN, 6)
	zone_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	zone_box.add_child(zone_sub)
	zone_title = _label("NEON DUSK", 96, Color.WHITE, 18)
	zone_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	zone_title.add_theme_color_override("font_shadow_color", Color(0.9, 0.2, 0.7, 0.8))
	zone_title.add_theme_constant_override("shadow_offset_x", 6)
	zone_title.add_theme_constant_override("shadow_offset_y", 8)
	zone_box.add_child(zone_title)
	zone_box.modulate.a = 0.0


func setup_abilities(abilities: Array) -> void:
	var hb: HBoxContainer = energy_bar.get_parent().get_parent().get_child(1).get_child(0)
	for a in abilities:
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 2)
		hb.add_child(v)
		var s := AbilitySlot.new()
		s.id = a["id"]
		s.key = a["key"]
		s.col = a["color"]
		s.fnt = font
		s.custom_minimum_size = Vector2(92, 100)
		v.add_child(s)
		var n := _label(a["name"], 13, TEXT_DIM, 4)
		n.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(n)
		slots.append(s)
		slot_names.append(n)


func _build_menu() -> void:
	menu = Control.new()
	menu.set_anchors_preset(Control.PRESET_FULL_RECT)
	menu.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(menu)

	# left gradient for readability
	var grad := Gradient.new()
	grad.set_color(0, Color(0.1, 0.03, 0.2, 0.85))
	grad.set_color(1, Color(0.1, 0.03, 0.2, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(1, 0)
	var tr := TextureRect.new()
	tr.texture = gt
	tr.anchor_bottom = 1.0
	tr.anchor_right = 0.62
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu.add_child(tr)

	title_box = VBoxContainer.new()
	title_box.anchor_top = 0.5
	title_box.anchor_bottom = 0.5
	title_box.offset_left = 120
	title_box.grow_vertical = Control.GROW_DIRECTION_BOTH
	title_box.add_theme_constant_override("separation", 6)
	menu.add_child(title_box)
	title_box.add_child(_label("ENDLESS  SKY  RUNNER", 26, CYAN, 6))
	var tv := VBoxContainer.new()
	tv.add_theme_constant_override("separation", -46)
	title_box.add_child(tv)
	var t1 := _label("SKYLINE", 164, PINK, 22)
	t1.add_theme_color_override("font_shadow_color", Color(0.35, 0.1, 0.6, 0.9))
	t1.add_theme_constant_override("shadow_offset_x", 8)
	t1.add_theme_constant_override("shadow_offset_y", 10)
	tv.add_child(t1)
	var t2 := _label("RUSH", 164, CYAN, 22)
	t2.add_theme_color_override("font_shadow_color", Color(0.1, 0.25, 0.6, 0.9))
	t2.add_theme_constant_override("shadow_offset_x", 8)
	t2.add_theme_constant_override("shadow_offset_y", 10)
	tv.add_child(t2)
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 6)
	title_box.add_child(spacer)
	title_box.add_child(_label("Run the neon sky-roads. Grab the gold. Drop the beat.", 28, TEXT_DIM, 6))
	var sp2 := Control.new()
	sp2.custom_minimum_size = Vector2(0, 30)
	title_box.add_child(sp2)
	var bh := HBoxContainer.new()
	bh.add_theme_constant_override("separation", 20)
	title_box.add_child(bh)
	var play := _button("PLAY   [SPACE]", PINK, 360)
	play.pressed.connect(func(): play_pressed.emit())
	bh.add_child(play)
	var quit := _button("QUIT", Color(0.6, 0.5, 0.9), 180)
	quit.pressed.connect(func(): quit_pressed.emit())
	bh.add_child(quit)
	var sp3 := Control.new()
	sp3.custom_minimum_size = Vector2(0, 16)
	title_box.add_child(sp3)
	# track selector
	var tp := _panel(Color(0.1, 0.05, 0.2, 0.75), Color(1, 0.4, 0.8, 0.45))
	title_box.add_child(tp)
	var th := HBoxContainer.new()
	th.add_theme_constant_override("separation", 18)
	tp.add_child(th)
	var prev := _button("<", CYAN, 64)
	prev.pressed.connect(func(): track_changed.emit(-1))
	th.add_child(prev)
	var tsv := VBoxContainer.new()
	tsv.custom_minimum_size = Vector2(380, 0)
	tsv.add_theme_constant_override("separation", -6)
	th.add_child(tsv)
	track_num = _label("TRACK 1 / 8   ·   A / D TO CHANGE", 17, TEXT_DIM, 0)
	track_num.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tsv.add_child(track_num)
	track_name = _label("SKY ROADS", 38, Color.WHITE, 8)
	track_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tsv.add_child(track_name)
	var nxt := _button(">", CYAN, 64)
	nxt.pressed.connect(func(): track_changed.emit(1))
	th.add_child(nxt)
	# character selector
	var cpn := _panel(Color(0.1, 0.05, 0.2, 0.75), Color(0.4, 0.9, 1.0, 0.45))
	title_box.add_child(cpn)
	var ch := HBoxContainer.new()
	ch.add_theme_constant_override("separation", 18)
	cpn.add_child(ch)
	var cprev := _button("<", PINK, 64)
	cprev.pressed.connect(func(): char_changed.emit(-1))
	ch.add_child(cprev)
	var cv2 := VBoxContainer.new()
	cv2.custom_minimum_size = Vector2(380, 0)
	cv2.add_theme_constant_override("separation", -6)
	ch.add_child(cv2)
	char_hobby = _label("RUNNER 1 / 6   ·   Q / E TO CHANGE", 17, TEXT_DIM, 0)
	char_hobby.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cv2.add_child(char_hobby)
	char_name = _label("FOX", 38, Color.WHITE, 8)
	char_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cv2.add_child(char_name)
	var cnext := _button(">", PINK, 64)
	cnext.pressed.connect(func(): char_changed.emit(1))
	ch.add_child(cnext)
	var sp4 := Control.new()
	sp4.custom_minimum_size = Vector2(0, 8)
	title_box.add_child(sp4)
	menu_best = _label("BEST  0", 30, GOLD, 8)
	title_box.add_child(menu_best)

	# controls panel (right)
	var cp := _panel(Color(0.1, 0.05, 0.2, 0.8), Color(0.4, 0.9, 1.0, 0.4))
	controls_panel = cp
	cp.visible = false
	cp.anchor_left = 1.0
	cp.anchor_right = 1.0
	cp.anchor_top = 0.5
	cp.anchor_bottom = 0.5
	cp.offset_right = -90
	cp.offset_left = -90
	cp.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	cp.grow_vertical = Control.GROW_DIRECTION_BOTH
	menu.add_child(cp)
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 8)
	cp.add_child(cv)
	cv.add_child(_label("CONTROLS", 30, CYAN, 0))
	var rows := [
		["A / D", "Switch lane  (push into a wall = wall run)", Color.WHITE],
		["W / SPACE", "Jump  -  hold higher, again = double jump", Color.WHITE],
		["S / CTRL", "Slide", Color.WHITE],
		["SHIFT", "DASH  -  burst, smash weak stuff, jump = dash-jump", Color(1.0, 0.35, 0.75)],
		["SHIFT (AIR)", "AIR DASH  -  forward, or sideways with A / D", Color(1.0, 0.6, 0.9)],
		["Q", "WALL RUN  -  run along neon walls", Color(0.45, 0.7, 1.0)],
		["E", "GRAPPLE  -  hook green anchors, swing over gaps", Color(0.4, 1.0, 0.6)],
		["R", "TIME SHIFT  -  slow the world down", Color(0.65, 0.6, 1.0)],
		["F", "PHASE  -  ghost through one obstacle (1 s)", CYAN],
		["C", "MAGNET PULL  -  yank cores + gold to you", Color(1.0, 0.45, 0.45)],
		["S (AIR)", "GROUND SLAM  -  smash down, bounce back up", GOLD],
	]
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 8)
	cv.add_child(grid)
	for r in rows:
		grid.add_child(_chip(r[0], r[2] if r[2] != Color.WHITE else Color(0.92, 0.88, 1.0)))
		grid.add_child(_label(r[1], 19, Color.WHITE, 0))
	var hint := _label("Cores:  cyan = shield  ·  pink = skip a cooldown  ·  gold = x2 score\nESC pause   ·   M music   ·   F11 fullscreen   ·   Gamepad supported", 17, TEXT_DIM, 0)
	cv.add_child(hint)
	controls_btn = _button("CONTROLS  [TAB]", CYAN, 260)
	controls_btn.anchor_left = 1.0
	controls_btn.anchor_right = 1.0
	controls_btn.anchor_top = 1.0
	controls_btn.anchor_bottom = 1.0
	controls_btn.offset_left = -300
	controls_btn.offset_right = -40
	controls_btn.offset_top = -100
	controls_btn.offset_bottom = -40
	controls_btn.pressed.connect(toggle_controls)
	menu.add_child(controls_btn)


func _center_panel(border: Color) -> VBoxContainer:
	var holder := Control.new()
	holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var dim := ColorRect.new()
	dim.color = Color(0.08, 0.02, 0.16, 0.55)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(dim)
	var p := _panel(Color(0.1, 0.05, 0.2, 0.92), border)
	p.anchor_left = 0.5
	p.anchor_right = 0.5
	p.anchor_top = 0.5
	p.anchor_bottom = 0.5
	p.grow_horizontal = Control.GROW_DIRECTION_BOTH
	p.grow_vertical = Control.GROW_DIRECTION_BOTH
	p.custom_minimum_size = Vector2(620, 0)
	holder.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	p.add_child(v)
	holder.set_meta("panel", p)
	root.add_child(holder)
	v.set_meta("holder", holder)
	return v


func _build_pause() -> void:
	var v := _center_panel(Color(0.4, 0.9, 1.0, 0.6))
	pause_panel = v.get_meta("holder")
	var t := _label("PAUSED", 72, CYAN, 12)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	var b1 := _button("RESUME   [ESC]", CYAN, 420)
	b1.pressed.connect(func(): resume_pressed.emit())
	v.add_child(b1)
	var b2 := _button("RESTART", PINK, 420)
	b2.pressed.connect(func(): retry_pressed.emit())
	v.add_child(b2)
	var b3 := _button("MAIN MENU", Color(0.6, 0.5, 0.9), 420)
	b3.pressed.connect(func(): menu_pressed.emit())
	v.add_child(b3)
	for b in [b1, b2, b3]:
		b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER


func _build_over() -> void:
	var v := _center_panel(Color(1, 0.4, 0.8, 0.7))
	over = v.get_meta("holder")
	over_title = _label("WIPED OUT", 76, PINK, 14)
	over_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(over_title)
	over_badge = _chip("NEW BEST!", GOLD)
	over_badge.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(over_badge)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 80)
	grid.add_theme_constant_override("v_separation", 6)
	grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(grid)
	for k in ["SCORE", "DISTANCE", "GOLD", "CLOSE CALLS", "BEST"]:
		grid.add_child(_label(k, 26, TEXT_DIM, 0))
		var val := _label("0", 30, Color.WHITE, 0)
		val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		grid.add_child(val)
		over_vals[k] = val
	over_vals["SCORE"].add_theme_color_override("font_color", PINK)
	over_vals["GOLD"].add_theme_color_override("font_color", GOLD)
	over_revive = _button("REVIVE  [R]", GOLD, 560)
	over_revive.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	over_revive.pressed.connect(func(): revive_pressed.emit())
	v.add_child(over_revive)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 20)
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_child(hb)
	var b1 := _button("RUN AGAIN  [SPACE]", PINK, 330)
	b1.pressed.connect(func(): retry_pressed.emit())
	hb.add_child(b1)
	var b2 := _button("MENU  [ESC]", Color(0.6, 0.5, 0.9), 220)
	b2.pressed.connect(func(): menu_pressed.emit())
	hb.add_child(b2)


# ============================================================ screens
func show_menu(best: int) -> void:
	menu.visible = true
	hud.visible = false
	pause_panel.visible = false
	over.visible = false
	menu_best.text = "BEST  %d" % best
	menu.modulate.a = 0.0
	create_tween().tween_property(menu, "modulate:a", 1.0, 0.5)


func toggle_controls() -> void:
	controls_panel.visible = not controls_panel.visible
	controls_btn.text = "HIDE CONTROLS  [TAB]" if controls_panel.visible else "CONTROLS  [TAB]"


func set_character(name: String, hobby: String, idx: int, total: int) -> void:
	char_name.text = name
	char_hobby.text = "RUNNER %d / %d  ·  %s  ·  Q / E" % [idx + 1, total, hobby.to_upper()]
	char_name.pivot_offset = char_name.size * 0.5
	char_name.scale = Vector2(1.2, 1.2)
	char_name.create_tween().tween_property(char_name, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK)


func set_track(name: String, idx: int, total: int) -> void:
	track_name.text = name
	track_num.text = "TRACK %d / %d   ·   A / D TO CHANGE" % [idx + 1, total]
	track_name.pivot_offset = track_name.size * 0.5
	track_name.scale = Vector2(1.2, 1.2)
	track_name.create_tween().tween_property(track_name, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK)


func show_game() -> void:
	menu.visible = false
	over.visible = false
	pause_panel.visible = false
	hud.visible = true
	hud.modulate.a = 0.0
	create_tween().tween_property(hud, "modulate:a", 1.0, 0.4)
	for c in popups.get_children():
		c.queue_free()
	_last_mult = 1


func show_pause(on: bool) -> void:
	pause_panel.visible = on


func show_over(d: Dictionary) -> void:
	over.visible = true
	over_title.text = d["title"]
	over_vals["SCORE"].text = _fmt(d["score"])
	over_vals["DISTANCE"].text = "%d m" % d["distance"]
	over_vals["GOLD"].text = "%d" % d["gold"]
	over_vals["CLOSE CALLS"].text = "%d" % d["close"]
	over_vals["BEST"].text = _fmt(d["best"])
	over_badge.visible = d["new_best"]
	over_revive.visible = d.get("revive", false)
	over_revive.text = "REVIVE  [R]   ·   %d GOLD" % d.get("revive_cost", 100)
	var p: Control = over.get_meta("panel")
	p.pivot_offset = p.size * 0.5
	p.scale = Vector2(0.85, 0.85)
	over.modulate.a = 0.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(over, "modulate:a", 1.0, 0.3)
	tw.tween_property(p, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func is_over_visible() -> bool:
	return over.visible


# ============================================================ runtime updates
func update_hud(score: int, dist: int, mult: int, gold: int, kmh: int, speed_ratio: float, flow: float, flow_tier: int, cores: Array, ab: Array) -> void:
	score_lbl.text = _fmt(score)
	dist_lbl.text = "%d m" % dist
	mult_lbl.text = "x%d" % mult
	if mult != _last_mult:
		_last_mult = mult
		mult_chip.pivot_offset = mult_chip.size * 0.5
		mult_chip.scale = Vector2(1.5, 1.5)
		create_tween().tween_property(mult_chip, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK)
	gold_lbl.text = _fmt(gold)
	speed_lbl.text = "%d KM/H" % kmh
	speed_bar.value = speed_ratio
	speed_bar.queue_redraw()
	energy_bar.value = flow / 100.0
	energy_bar.text = "FLOW  %d%%%s" % [int(flow), ("   ·   BONUS  +%d" % flow_tier) if flow_tier > 0 else ""]
	energy_bar.glow = (0.5 + 0.5 * sin(_t * 8.0)) if flow_tier >= 2 else 0.0
	energy_bar.queue_redraw()
	if cores != cores_icon.cores:
		cores_icon.cores = cores.duplicate()
		cores_icon.queue_redraw()
	for i in slots.size():
		var s: AbilitySlot = slots[i]
		var a: Dictionary = ab[i]
		if a["ready"] and not s.is_ready:
			s.bump = 1.0
		s.is_ready = a["ready"]
		s.cd_ratio = a["cd_ratio"]
		s.cd_left = a["cd_left"]
		s.active_ratio = a["active_ratio"]
		s.queue_redraw()


func slot_used(i: int) -> void:
	if i < slots.size():
		slots[i].bump = 1.0


func slot_deny(i: int) -> void:
	if i < slots.size():
		slots[i].deny = 0.35


func gold_pop() -> void:
	_gold_pop = 1.0


func popup(text: String, color: Color, size := 44) -> void:
	var l := _label(text, size, color, 12)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	popups.add_child(l)
	if popups.get_child_count() > 4:
		popups.get_child(0).queue_free()
	l.pivot_offset = Vector2(300, size * 0.6)
	l.custom_minimum_size = Vector2(600, 0)
	l.scale = Vector2(1.5, 1.5)
	var tw := l.create_tween()
	tw.tween_property(l, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_interval(0.8)
	tw.tween_property(l, "modulate:a", 0.0, 0.4)
	tw.tween_callback(l.queue_free)


func flash(color: Color, amount: float) -> void:
	_flash_color = color
	_flash = maxf(_flash, amount)


func set_post(aberration: float, tint_amount: float, blur := 0.0, tint := Color(0.6, 0.8, 1.0)) -> void:
	post_mat.set_shader_parameter("aberration", aberration)
	post_mat.set_shader_parameter("tint_amount", tint_amount)
	post_mat.set_shader_parameter("radial_blur", blur)
	post_mat.set_shader_parameter("tint", tint)


func set_markers(list: Array) -> void:
	markers_layer.markers = list
	markers_layer.queue_redraw()


func set_prompt(text: String) -> void:
	if prompt_lbl.text != text:
		prompt_lbl.text = text
		prompt_lbl.modulate.a = 0.0
		if text != "":
			prompt_lbl.create_tween().tween_property(prompt_lbl, "modulate:a", 1.0, 0.2)
	if text != "":
		prompt_lbl.modulate = Color(1, 1, 1, clampf(prompt_lbl.modulate.a, 0.0, 1.0))


func zone_banner(title: String, sub: String) -> void:
	zone_title.text = title
	zone_sub.text = sub
	zone_box.pivot_offset = Vector2(zone_box.size.x * 0.5, 60)
	zone_box.scale = Vector2(1.4, 1.4)
	zone_box.modulate.a = 0.0
	var tw := zone_box.create_tween()
	tw.set_parallel(true)
	tw.tween_property(zone_box, "modulate:a", 1.0, 0.35)
	tw.tween_property(zone_box, "scale", Vector2.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.chain().tween_interval(1.8)
	tw.chain().tween_property(zone_box, "modulate:a", 0.0, 0.6)


func _process(delta: float) -> void:
	_t += delta
	_flash = maxf(0.0, _flash - delta * 2.5)
	post_mat.set_shader_parameter("flash", _flash)
	post_mat.set_shader_parameter("flash_color", _flash_color)
	_gold_pop = maxf(0.0, _gold_pop - delta * 6.0)
	if markers_layer and not markers_layer.markers.is_empty():
		markers_layer.t = _t
		markers_layer.queue_redraw()
	if gold_icon:
		gold_icon.pop = _gold_pop
		gold_icon.queue_redraw()
	for s in slots:
		if s.bump > 0.0 or s.deny > 0.0:
			s.bump = maxf(0.0, s.bump - delta * 3.0)
			s.deny = maxf(0.0, s.deny - delta)
			s.queue_redraw()


func _fmt(n: int) -> String:
	var s := str(n)
	var out := ""
	var c := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		c += 1
		if c % 3 == 0 and i > 0:
			out = "," + out
	return out
