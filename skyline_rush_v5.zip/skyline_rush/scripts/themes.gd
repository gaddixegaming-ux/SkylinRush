extends RefCounted
## Track / town themes. Each theme dresses the road (tile style), the sides
## (buildings + props), the space over the road and the distant skyline.
## 0 is the original sky-road; 1-7 are the towns.

const NAMES := [
	"SKY ROADS", "LANTERN FESTIVAL", "SKATE PARK", "NEON RAIN ALLEY",
	"NEON MARKET", "HOVER HARBOR", "SAKURA HEIGHTS", "CANDY CARNIVAL",
]
const ACCENT := [
	Color(1.0, 0.3, 0.75), Color(1.0, 0.32, 0.3), Color(0.3, 0.7, 1.0), Color(0.85, 0.3, 1.0),
	Color(0.3, 0.95, 1.0), Color(0.4, 1.0, 0.8), Color(1.0, 0.55, 0.78), Color(1.0, 0.75, 0.3),
]
const STREET := {
	1: {"deck": Color(0.52, 0.48, 0.64), "deck2": Color(0.56, 0.51, 0.67), "dash": Color(1.0, 0.9, 0.7), "dash_e": 0.4,
		"curb": Color(0.97, 0.86, 0.82), "walk": Color(0.96, 0.8, 0.72), "ground": Color(0.92, 0.78, 0.66), "rough": 0.8, "metal": 0.0},
	2: {"deck": Color(0.8, 0.72, 0.6), "deck2": Color(0.77, 0.7, 0.58), "dash": Color(0.72, 0.45, 0.95), "dash_e": 0.3,
		"curb": Color(0.7, 0.66, 0.6), "walk": Color(0.78, 0.72, 0.6), "ground": Color(0.62, 0.72, 0.5), "rough": 0.9, "metal": 0.0},
	3: {"deck": Color(0.1, 0.1, 0.17), "deck2": Color(0.12, 0.11, 0.19), "dash": Color(0.5, 0.6, 1.0), "dash_e": 1.8,
		"curb": Color(0.2, 0.2, 0.28), "walk": Color(0.15, 0.14, 0.21), "ground": Color(0.07, 0.07, 0.12), "rough": 0.05, "metal": 0.7},
	4: {"deck": Color(0.27, 0.26, 0.33), "deck2": Color(0.29, 0.28, 0.35), "dash": Color(1.0, 1.0, 1.0), "dash_e": 0.6,
		"curb": Color(0.86, 0.8, 0.92), "walk": Color(0.55, 0.5, 0.63), "ground": Color(0.38, 0.34, 0.46), "rough": 0.55, "metal": 0.1},
	6: {"deck": Color(0.74, 0.7, 0.72), "deck2": Color(0.7, 0.66, 0.69), "dash": Color(1.0, 0.75, 0.86), "dash_e": 0.35,
		"curb": Color(0.42, 0.6, 0.38), "walk": Color(0.82, 0.77, 0.73), "ground": Color(0.55, 0.72, 0.45), "rough": 0.85, "metal": 0.0},
	7: {"deck": Color(0.8, 0.54, 0.4), "deck2": Color(0.72, 0.47, 0.35), "dash": Color(1.0, 0.9, 0.5), "dash_e": 1.2,
		"curb": Color(0.95, 0.3, 0.36), "walk": Color(0.96, 0.86, 0.76), "ground": Color(0.42, 0.28, 0.42), "rough": 0.7, "metal": 0.0},
}
const PINK := Color(1.0, 0.3, 0.75)
const CYAN := Color(0.3, 0.9, 1.0)
const GOLD := Color(1.0, 0.75, 0.2)
const TILE := 4.0

var w  # the world node


func _init(world) -> void:
	w = world


func is_sky(t: int) -> bool:
	return t == 0 or t == 5


# ============================================================ helpers
func node(pos: Vector3, half: float) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	n.set_meta("half", half)
	w.scenery.add_child(n)
	return n


func M(albedo: Color, emission := Color(0, 0, 0), energy := 0.0, rough := 0.7, metal := 0.0, rim := 0.15, pulse := 0.0) -> ShaderMaterial:
	return w.mat(albedo, emission, energy, rough, metal, rim, pulse)


func G(c: Color, energy := 2.5, pulse := 0.0) -> ShaderMaterial:
	return w.mat(c, c, energy, 0.4, 0.0, 0.0, pulse)


func box(p: Node3D, size: Vector3, pos: Vector3, m: Material, shadow := false, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi: MeshInstance3D = w._box(p, size, pos, m, shadow)
	mi.rotation = rot
	return mi


func cyl(p: Node3D, r: float, h: float, pos: Vector3, m: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	return w._cyl(p, r, h, pos, m, rot, false)


func sph(p: Node3D, r: float, pos: Vector3, m: Material, sq := 1.0) -> MeshInstance3D:
	var mi: MeshInstance3D = w._sphere(p, r, pos, m, false)
	mi.scale.y *= sq
	return mi


func cone(p: Node3D, r: float, h: float, pos: Vector3, m: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi: MeshInstance3D = w._mi(p, w._mesh("cone"), pos, m, false)
	mi.rotation = rot
	mi.scale = Vector3(r, h, r)
	return mi


func light(p: Node3D, pos: Vector3, c: Color, energy := 2.0, rng := 7.0) -> void:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = c
	l.light_energy = energy
	l.omni_range = rng
	l.omni_attenuation = 1.5
	l.shadow_enabled = false
	p.add_child(l)


func pick(a: Array):
	return a[randi() % a.size()]


# ============================================================ road tiles
func build_tile(n: Node3D, t: int, idx: int) -> void:
	if t == 0:
		_tile_sky(n, idx)
		return
	if t == 5:
		_tile_harbor(n, idx)
		return
	var s: Dictionary = STREET[t]
	var deck: Color = s["deck"] if idx % 2 == 0 else s["deck2"]
	box(n, Vector3(8.4, 0.5, TILE), Vector3(0, -0.25, 0), M(deck, Color.BLACK, 0.0, s["rough"], s["metal"], 0.03), false)
	box(n, Vector3(160.0, 0.4, TILE), Vector3(0, -0.62, 0), M(s["ground"], Color.BLACK, 0.0, 0.95, 0.0, 0.0))
	var curb := M(s["curb"], Color.BLACK, 0.0, 0.7)
	var walk := M(s["walk"], Color.BLACK, 0.0, s["rough"] + 0.1, s["metal"] * 0.5)
	for sd in [-1.0, 1.0]:
		box(n, Vector3(0.35, 0.28, TILE), Vector3(sd * 4.37, 0.03, 0), curb)
		box(n, Vector3(3.2, 0.26, TILE), Vector3(sd * 6.1, 0.0, 0), walk)
	if idx % 2 == 0:
		var dm: Material = w.mat(s["dash"], s["dash"], s["dash_e"], 0.5)
		box(n, Vector3(0.12, 0.03, 2.2), Vector3(-1.25, 0.015, 0), dm)
		box(n, Vector3(0.12, 0.03, 2.2), Vector3(1.25, 0.015, 0), dm)
	match t:
		1:
			if idx % 3 == 0:
				box(n, Vector3(3.2, 0.02, 0.12), Vector3(6.1, 0.14, 1.0), M(Color(0.85, 0.65, 0.6)))
				box(n, Vector3(3.2, 0.02, 0.12), Vector3(-6.1, 0.14, 1.0), M(Color(0.85, 0.65, 0.6)))
		2:
			if randf() < 0.18:
				var c: Color = pick([Color(1, 0.45, 0.75), Color(0.4, 0.75, 1), Color(1, 0.85, 0.3), Color(0.6, 0.9, 0.5)])
				var d := cyl(n, randf_range(0.6, 1.4), 0.02, Vector3(randf_range(-3, 3), 0.012, randf_range(-1, 1)), M(c, Color.BLACK, 0, 0.9))
				d.scale.x *= randf_range(1.0, 2.2)
		3:
			var joint := M(Color(0.05, 0.05, 0.09), Color.BLACK, 0.0, 0.3)
			box(n, Vector3(8.4, 0.01, 0.06), Vector3(0, 0.005, 1.0), joint)
			box(n, Vector3(8.4, 0.01, 0.06), Vector3(0, 0.005, -1.0), joint)
		4:
			box(n, Vector3(0.55, 0.02, TILE), Vector3(-3.9, 0.012, 0), G(PINK, 2.2, 0.6))
			box(n, Vector3(0.06, 0.03, TILE), Vector3(-3.58, 0.015, 0), G(Color(1, 0.9, 0.95), 1.5))
		6:
			for sd in [-1.0, 1.0]:
				box(n, Vector3(0.5, 0.05, TILE), Vector3(sd * 4.0, 0.01, 0), M(Color(0.45, 0.62, 0.35), Color.BLACK, 0, 0.95))
			for k in 3:
				box(n, Vector3(0.12, 0.01, 0.08), Vector3(randf_range(-3.5, 3.5), 0.006, randf_range(-1.8, 1.8)), M(Color(1, 0.75, 0.85)), false, Vector3(0, randf() * TAU, 0))
		7:
			var plank := M(Color(0.45, 0.28, 0.22), Color.BLACK, 0.0, 0.9)
			box(n, Vector3(8.4, 0.01, 0.07), Vector3(0, 0.005, 0.0), plank)
			var bulb: Color = [Color(1, 0.85, 0.4), Color(1, 0.4, 0.5), Color(0.5, 0.9, 1)][idx % 3]
			for sd in [-1.0, 1.0]:
				sph(n, 0.13, Vector3(sd * 4.37, 0.25, 0), G(bulb, 4.0, 1.0))


func _tile_sky(n: Node3D, idx: int) -> void:
	var deck_c := Color(0.2, 0.12, 0.33) if idx % 2 == 0 else Color(0.24, 0.15, 0.38)
	box(n, Vector3(8.4, 0.5, TILE), Vector3(0, -0.25, 0), M(deck_c, Color.BLACK, 0.0, 0.35, 0.35, 0.05), true)
	box(n, Vector3(6.4, 0.9, TILE), Vector3(0, -0.95, 0), M(Color(0.34, 0.24, 0.5), Color.BLACK, 0.0, 0.5, 0.4, 0.2))
	var rail := G(PINK, 2.5, 0.8)
	box(n, Vector3(0.3, 0.35, TILE), Vector3(-4.25, 0.12, 0), rail)
	box(n, Vector3(0.3, 0.35, TILE), Vector3(4.25, 0.12, 0), rail)
	if idx % 2 == 0:
		var dash := G(CYAN, 1.6)
		box(n, Vector3(0.12, 0.03, 2.2), Vector3(-1.25, 0.015, 0), dash)
		box(n, Vector3(0.12, 0.03, 2.2), Vector3(1.25, 0.015, 0), dash)
	if idx % 4 == 0:
		var side_l := G(CYAN, 3.0, 1.0)
		box(n, Vector3(0.05, 0.25, 1.2), Vector3(-3.21, -0.95, 0), side_l)
		box(n, Vector3(0.05, 0.25, 1.2), Vector3(3.21, -0.95, 0), side_l)


func _tile_harbor(n: Node3D, idx: int) -> void:
	var deck := Color(0.93, 0.91, 0.96) if idx % 2 == 0 else Color(0.9, 0.88, 0.94)
	box(n, Vector3(8.4, 0.5, TILE), Vector3(0, -0.25, 0), M(deck, Color.BLACK, 0.0, 0.25, 0.2, 0.25), true)
	box(n, Vector3(7.0, 0.7, TILE), Vector3(0, -0.8, 0), M(Color(0.75, 0.78, 0.9), Color.BLACK, 0.0, 0.3, 0.5, 0.2))
	var cols := [Color(0.3, 0.95, 1.0), Color(0.4, 1.0, 0.6), Color(1.0, 0.45, 0.8)]
	for i in 3:
		box(n, Vector3(0.14, 0.06, TILE), Vector3(-3.9 + i * 0.2, 0.03, 0), G(cols[i], 2.5, 0.8))
		box(n, Vector3(0.14, 0.06, TILE), Vector3(3.9 - i * 0.2, 0.03, 0), G(cols[i], 2.5, 0.8))
	box(n, Vector3(0.35, 0.4, TILE), Vector3(-4.3, 0.15, 0), M(Color(0.95, 0.95, 1.0), Color.BLACK, 0.0, 0.2, 0.3, 0.3))
	box(n, Vector3(0.35, 0.4, TILE), Vector3(4.3, 0.15, 0), M(Color(0.95, 0.95, 1.0), Color.BLACK, 0.0, 0.2, 0.3, 0.3))
	if idx % 2 == 0:
		box(n, Vector3(0.12, 0.03, 2.2), Vector3(-1.25, 0.015, 0), G(Color(0.4, 0.8, 1.0), 1.4))
		box(n, Vector3(0.12, 0.03, 2.2), Vector3(1.25, 0.015, 0), G(Color(0.4, 0.8, 1.0), 1.4))
	if idx % 3 == 0:
		cone(n, 0.5, 1.0, Vector3(-2.5, -1.5, 0), G(CYAN, 3.0, 1.0), Vector3(PI, 0, 0))
		cone(n, 0.5, 1.0, Vector3(2.5, -1.5, 0), G(CYAN, 3.0, 1.0), Vector3(PI, 0, 0))


# ============================================================ side dressing
## Spawns something at z on one side, returns spacing to the next one.
func side(z: float, s: float, t: int) -> float:
	match t:
		1: return _festival_side(z, s)
		2: return _skate_side(z, s)
		3: return _rain_side(z, s)
		4: return _market_side(z, s)
		5: return _harbor_side(z, s)
		6: return _sakura_side(z, s)
		7: return _carnival_side(z, s)
	return 30.0


func overhead(z: float, t: int) -> float:
	match t:
		1: _lantern_string(z, 6.8, [Color(1.0, 0.32, 0.3), Color(1.0, 0.45, 0.35)], false)
		2: _pennants(z)
		3: _lantern_string(z, 6.2, [Color(1.0, 0.25, 0.3), Color(1.0, 0.5, 0.2)], true)
		4: _power_lines(z)
		5: _light_ring(z)
		6: _torii(z, 1.0)
		7: _bulb_string(z)
		_: return 40.0
	match t:
		1: return randf_range(9.0, 13.0)
		2: return randf_range(22.0, 30.0)
		3: return randf_range(10.0, 14.0)
		4: return randf_range(14.0, 18.0)
		5: return randf_range(28.0, 40.0)
		6: return randf_range(30.0, 40.0)
	return randf_range(9.0, 12.0)


func far(z: float, t: int) -> float:
	var s := -1.0 if randf() < 0.5 else 1.0
	match t:
		1: _festival_far(z, s)
		2: _skate_far(z, s)
		3: _rain_far(z, s)
		4: _market_far(z, s)
		5: _harbor_far(z, s)
		6: _sakura_far(z, s)
		7: _carnival_far(z, s)
		_: return 60.0
	return randf_range(22.0, 40.0)


## Big welcome arch where one theme hands over to the next.
func gate(z: float, t: int) -> void:
	var n := node(Vector3(0, 0, z), 2.0)
	var a: Color = ACCENT[t]
	if t == 6:
		_torii(z, 1.5)
		return
	var body := M(Color(0.2, 0.16, 0.28), Color.BLACK, 0.0, 0.4, 0.5, 0.3)
	for sd in [-1.0, 1.0]:
		box(n, Vector3(1.2, 11.0, 1.2), Vector3(sd * 6.2, 5.5, 0), body, true)
		box(n, Vector3(1.3, 0.25, 1.3), Vector3(sd * 6.2, 3.0, 0), G(a, 3.0, 1.0))
		box(n, Vector3(1.3, 0.25, 1.3), Vector3(sd * 6.2, 7.0, 0), G(a, 3.0, 1.0))
		w._beam(n, Vector3(sd * 6.2, 11.0, 0), 0.6, 30.0, a, 0.3)
	box(n, Vector3(14.0, 1.6, 1.4), Vector3(0, 10.6, 0), body, true)
	box(n, Vector3(13.0, 0.9, 0.05), Vector3(0, 10.6, 0.72), G(a, 3.5, 1.2))
	for i in 7:
		sph(n, 0.25, Vector3(-4.5 + i * 1.5, 9.6, 0.6), G(Color(1, 1, 1), 4.0, 1.0))


# ---------------------------------------------------------------- buildings
func _shophouse(z: float, s: float, o: Dictionary) -> float:
	var wd := randf_range(5.5, 8.0)
	var dp := randf_range(6.0, 9.0)
	var floors := randi_range(o.get("fmin", 2), o.get("fmax", 4))
	var fh := 3.2
	var h := floors * fh
	var n := node(Vector3(s * (7.8 + dp * 0.5), 0, z - wd * 0.5), wd)
	var col: Color = pick(o["colors"])
	var night: bool = o.get("night", false)
	box(n, Vector3(dp, h, wd - 0.3), Vector3(0, h * 0.5, 0), M(col, Color.BLACK, 0.0, 0.8, 0.0, 0.2), true)
	var fx := -s * (dp * 0.5 + 0.03)
	var trim := M(col.darkened(0.3), Color.BLACK, 0.0, 0.7)
	# shop front
	var shop_c := Color(1.0, 0.75, 0.45) if night else Color(0.55, 0.7, 0.85)
	box(n, Vector3(0.06, 2.0, wd * 0.7), Vector3(fx, 1.3, 0), w.mat(shop_c, shop_c, 1.6 if night else 0.25, 0.2, 0.3, 0.2))
	box(n, Vector3(0.2, 0.3, wd - 0.2), Vector3(fx - s * 0.05, fh - 0.15, 0), trim)
	if o.get("awning", true):
		var ac: Color = pick(o.get("awnings", [Color(1, 0.45, 0.45), Color(0.4, 0.7, 0.95), Color(0.5, 0.85, 0.6), Color(1, 0.8, 0.4)]))
		box(n, Vector3(1.8, 0.12, wd * 0.8), Vector3(fx - s * 0.85, 2.75, 0), M(ac, ac, 0.1, 0.8), false, Vector3(0, 0, s * 0.35))
		box(n, Vector3(1.8, 0.13, wd * 0.18), Vector3(fx - s * 0.85, 2.76, wd * 0.2), M(Color(0.98, 0.96, 0.92)), false, Vector3(0, 0, s * 0.35))
	# windows on upper floors
	var win_c: Color = o.get("win", Color(0.65, 0.8, 0.95))
	var cols := int(wd / 1.8)
	for f in range(1, floors):
		for k in cols:
			var lit: bool = night and randf() < 0.6
			var wc := Color(1.0, 0.8, 0.5) if lit else win_c
			var zz := -wd * 0.5 + 0.9 + k * (wd - 1.8) / maxf(1.0, cols - 1)
			box(n, Vector3(0.06, 1.3, 0.9), Vector3(fx, f * fh + 1.5, zz), w.mat(wc, wc, 1.8 if lit else 0.05, 0.2, 0.2, 0.2))
			box(n, Vector3(0.12, 0.12, 1.1), Vector3(fx - s * 0.05, f * fh + 0.8, zz), trim)
	if floors >= 3 and randf() < 0.6:
		box(n, Vector3(1.0, 0.15, wd * 0.6), Vector3(fx - s * 0.5, fh * 2.0, 0), trim)
		box(n, Vector3(0.05, 0.8, wd * 0.6), Vector3(fx - s * 0.98, fh * 2.0 + 0.45, 0), trim)
	# roof
	match o.get("roof", "flat"):
		"flat":
			box(n, Vector3(dp + 0.3, 0.35, wd), Vector3(0, h + 0.15, 0), trim)
			if randf() < 0.4:
				cyl(n, 0.8, 1.8, Vector3(s * 1.0, h + 1.2, randf_range(-1, 1)), M(Color(0.55, 0.5, 0.55)))
		"tile":
			var rc: Color = o.get("roof_c", Color(0.12, 0.12, 0.16))
			box(n, Vector3(dp * 0.62, 0.22, wd + 0.8), Vector3(-s * dp * 0.22, h + 0.9, 0), M(rc, Color.BLACK, 0, 0.6, 0.2), true, Vector3(0, 0, s * 0.45))
			box(n, Vector3(dp * 0.62, 0.22, wd + 0.8), Vector3(s * dp * 0.22, h + 0.9, 0), M(rc, Color.BLACK, 0, 0.6, 0.2), true, Vector3(0, 0, -s * 0.45))
			box(n, Vector3(2.6, 0.15, wd + 0.4), Vector3(fx - s * 0.9, fh - 0.05, 0), M(rc, Color.BLACK, 0, 0.6), false, Vector3(0, 0, s * 0.3))
	# signage
	var sign_c: Color = pick(o.get("signs", [PINK, CYAN, Color(1, 0.8, 0.3)]))
	match o.get("sign", "vertical"):
		"vertical":
			var sh := randf_range(2.8, 4.5)
			var sy := fh + sh * 0.5 + 0.3
			var sz := randf_range(-wd * 0.3, wd * 0.3)
			box(n, Vector3(0.9, sh + 0.2, 0.3), Vector3(fx - s * 0.6, sy, sz), M(Color(0.08, 0.06, 0.1)))
			box(n, Vector3(0.95, sh, 0.22), Vector3(fx - s * 0.6, sy, sz), G(sign_c, 2.8 if night else 1.4, 0.4))
			for g in int(sh / 0.7):
				box(n, Vector3(0.5, 0.35, 0.05), Vector3(fx - s * 0.6, sy - sh * 0.5 + 0.45 + g * 0.7, sz + 0.13), G(Color(1, 1, 1), 2.0))
			if night:
				light(n, Vector3(fx - s * 1.6, sy, sz), sign_c, 2.5, 8.0)
		"panel":
			var pw := randf_range(2.0, 3.6)
			box(n, Vector3(0.3, 1.1, pw + 0.2), Vector3(fx - s * 0.15, fh + 0.9, 0), M(Color(0.1, 0.08, 0.14)))
			box(n, Vector3(0.1, 0.9, pw), Vector3(fx - s * 0.32, fh + 0.9, 0), G(sign_c, 2.2, 0.3))
			if night:
				light(n, Vector3(fx - s * 1.5, fh + 0.9, 0), sign_c, 2.0, 7.0)
	if o.get("lanterns", false):
		for k in 2:
			var lz := -wd * 0.25 + k * wd * 0.5
			sph(n, 0.35, Vector3(fx - s * 1.3, 2.9, lz), G(Color(1.0, 0.3, 0.25), 2.5 if night else 0.8), 1.25)
			cyl(n, 0.2, 0.08, Vector3(fx - s * 1.3, 3.35, lz), M(Color(0.9, 0.7, 0.2)))
	if o.get("ac", false):
		for k in randi_range(1, 3):
			var ay := randf_range(fh + 0.8, h - 0.8)
			var az := randf_range(-wd * 0.35, wd * 0.35)
			box(n, Vector3(0.6, 0.6, 0.9), Vector3(fx - s * 0.3, ay, az), M(Color(0.85, 0.85, 0.9), Color.BLACK, 0, 0.4, 0.3))
			cyl(n, 0.22, 0.05, Vector3(fx - s * 0.62, ay, az), M(Color(0.3, 0.3, 0.35)), Vector3(0, 0, PI / 2))
		cyl(n, 0.1, h, Vector3(fx - s * 0.12, h * 0.5, wd * 0.45), M(Color(0.35, 0.33, 0.4), Color.BLACK, 0, 0.4, 0.6))
	if o.get("plants", false) and randf() < 0.6:
		cyl(n, 0.35, 0.5, Vector3(fx - s * 1.0, 0.4, wd * 0.4), M(Color(0.3, 0.25, 0.3)))
		sph(n, 0.6, Vector3(fx - s * 1.0, 1.0, wd * 0.4), M(Color(0.2, 0.45, 0.3), Color.BLACK, 0, 0.9, 0, 0.3))
	return wd + randf_range(0.2, 1.2)


func _person(p: Node3D, pos: Vector3, facing: float) -> void:
	var n := Node3D.new()
	n.position = pos
	n.rotation.y = facing
	p.add_child(n)
	var top: Color = pick([Color(0.95, 0.4, 0.4), Color(0.4, 0.6, 0.95), Color(0.95, 0.8, 0.35), Color(0.5, 0.85, 0.6), Color(0.8, 0.5, 0.9)])
	var pants: Color = pick([Color(0.25, 0.25, 0.4), Color(0.35, 0.3, 0.25), Color(0.2, 0.3, 0.35)])
	var skin: Color = pick([Color(1.0, 0.82, 0.68), Color(0.85, 0.62, 0.45), Color(0.55, 0.38, 0.28)])
	box(n, Vector3(0.18, 0.75, 0.2), Vector3(-0.12, 0.38, 0), M(pants))
	box(n, Vector3(0.18, 0.75, 0.2), Vector3(0.12, 0.38, 0), M(pants))
	box(n, Vector3(0.5, 0.65, 0.3), Vector3(0, 1.08, 0), M(top), true)
	box(n, Vector3(0.14, 0.6, 0.16), Vector3(-0.33, 1.05, 0), M(top))
	box(n, Vector3(0.14, 0.6, 0.16), Vector3(0.33, 1.05, 0), M(top))
	sph(n, 0.22, Vector3(0, 1.62, 0), M(skin))
	box(n, Vector3(0.44, 0.14, 0.42), Vector3(0, 1.8, 0.02), M(pick([Color(0.15, 0.1, 0.08), Color(0.9, 0.75, 0.35), Color(0.35, 0.2, 0.12)])))
	w.bobbers.append([n, pos.y, 0.05, randf_range(2.0, 4.0), randf() * TAU])


func _lamp(p: Node3D, pos: Vector3, s: float, lamp_c: Color, pole_c: Color, lit := false) -> void:
	var pole := M(pole_c, Color.BLACK, 0.0, 0.4, 0.6)
	cyl(p, 0.1, 5.2, pos + Vector3(0, 2.6, 0), pole)
	box(p, Vector3(1.6, 0.1, 0.1), pos + Vector3(-s * 0.7, 5.1, 0), pole, false, Vector3(0, 0, s * 0.25))
	sph(p, 0.28, pos + Vector3(-s * 1.4, 4.85, 0), G(lamp_c, 3.0 if lit else 1.0), 0.7)
	if lit:
		light(p, pos + Vector3(-s * 1.4, 4.3, 0), lamp_c, 2.5, 9.0)


func _car_decor(p: Node3D, pos: Vector3) -> void:
	var c: Color = pick([Color(1.0, 0.8, 0.3), Color(0.5, 0.7, 0.95), Color(0.95, 0.5, 0.5), Color(0.9, 0.9, 0.95)])
	box(p, Vector3(1.7, 0.6, 3.8), pos + Vector3(0, 0.55, 0), M(c, Color.BLACK, 0, 0.3, 0.4, 0.3), true)
	box(p, Vector3(1.5, 0.5, 2.0), pos + Vector3(0, 1.1, 0.2), M(Color(0.3, 0.4, 0.55), Color.BLACK, 0, 0.1, 0.6, 0.3))
	for wx in [-0.8, 0.8]:
		for wz in [-1.2, 1.2]:
			cyl(p, 0.3, 0.25, pos + Vector3(wx, 0.3, wz), M(Color(0.1, 0.1, 0.12)), Vector3(0, 0, PI / 2))


# ---------------------------------------------------------------- 1 lantern festival
func _festival_side(z: float, s: float) -> float:
	var r := randf()
	if r < 0.72:
		var sp := _shophouse(z, s, {"colors": [Color(1.0, 0.72, 0.78), Color(0.78, 0.72, 1.0), Color(0.65, 0.9, 0.85), Color(1.0, 0.82, 0.62), Color(0.62, 0.8, 1.0)],
			"sign": pick(["vertical", "panel"]), "lanterns": randf() < 0.5, "fmin": 2, "fmax": 4, "signs": [Color(1, 0.35, 0.35), Color(0.3, 0.75, 0.6), Color(1, 0.8, 0.3)]})
		if randf() < 0.5:
			var pn := node(Vector3(s * randf_range(5.2, 7.0), 0.12, z - 2.0), 1.0)
			_person(pn, Vector3.ZERO, s * PI * 0.5 + randf_range(-0.8, 0.8))
		return sp
	var n := node(Vector3(s * 6.3, 0.12, z), 3.0)
	if r < 0.86:
		# market stall with umbrella
		var uc: Color = pick([Color(1, 0.4, 0.45), Color(0.4, 0.75, 0.6), Color(1, 0.8, 0.4)])
		cyl(n, 0.05, 2.4, Vector3(0, 1.2, 0), M(Color(0.3, 0.3, 0.3)))
		cone(n, 1.4, 0.7, Vector3(0, 2.6, 0), M(uc, uc, 0.1, 0.8))
		box(n, Vector3(1.4, 0.8, 1.6), Vector3(0, 0.4, 0), M(Color(0.75, 0.55, 0.4)))
		for k in 4:
			sph(n, 0.14, Vector3(randf_range(-0.5, 0.5), 0.9, randf_range(-0.6, 0.6)), M(pick([Color(1, 0.4, 0.2), Color(1, 0.8, 0.2), Color(0.5, 0.9, 0.3)])))
	else:
		_lamp(n, Vector3(s * -1.5, 0, 0), s, Color(1, 0.9, 0.7), Color(0.25, 0.4, 0.6))
		_car_decor(n, Vector3(s * -1.2, 0, -3.0))
	return randf_range(3.0, 6.0)


func _lantern_string(z: float, y: float, cols: Array, night: bool) -> void:
	var n := node(Vector3(0, 0, z), 1.0)
	var wire := M(Color(0.2, 0.2, 0.25))
	var span := 15.0
	var count := 9
	var zz := randf_range(-1.5, 1.5)
	for i in count:
		var t := float(i) / (count - 1)
		var x := -span * 0.5 + span * t
		var yy := y - 1.4 * sin(t * PI)
		var c: Color = cols[i % cols.size()]
		sph(n, 0.32, Vector3(x, yy - 0.45, zz * t), G(c, 1.6 if night else 1.0, 0.6), 1.3)
		cyl(n, 0.18, 0.08, Vector3(x, yy - 0.02, zz * t), M(Color(0.95, 0.75, 0.2)))
		box(n, Vector3(0.04, 0.3, 0.04), Vector3(x, yy - 0.95, zz * t), M(Color(0.95, 0.75, 0.2)))
		if i < count - 1:
			var t2 := float(i + 1) / (count - 1)
			var a := Vector3(x, yy, zz * t)
			var b := Vector3(-span * 0.5 + span * t2, y - 1.4 * sin(t2 * PI), zz * t2)
			var seg := box(n, Vector3((b - a).length(), 0.03, 0.03), (a + b) * 0.5, wire)
			seg.rotation.z = atan2(b.y - a.y, b.x - a.x)
	if night and randf() < 0.5:
		light(n, Vector3(0, y - 1.8, 0), cols[0], 2.0, 9.0)


func _festival_far(z: float, s: float) -> void:
	var n := node(Vector3(s * randf_range(22.0, 60.0), 0, z), 10.0)
	if randf() < 0.14:
		# observation needle tower
		var m := M(Color(0.85, 0.85, 0.95), Color.BLACK, 0, 0.4, 0.2, 0.3)
		cyl(n, 1.6, 50.0, Vector3(0, 25.0, 0), m)
		cyl(n, 4.0, 3.0, Vector3(0, 44.0, 0), m)
		cyl(n, 4.2, 0.4, Vector3(0, 45.0, 0), G(Color(0.6, 0.85, 1.0), 1.5))
		cyl(n, 0.4, 16.0, Vector3(0, 58.0, 0), m)
		return
	for k in randi_range(1, 3):
		var h := randf_range(14.0, 40.0)
		var wd := randf_range(6.0, 11.0)
		var c: Color = pick([Color(0.75, 0.82, 1.0), Color(0.95, 0.8, 0.9), Color(0.85, 0.95, 1.0), Color(1.0, 0.9, 0.75)])
		var off := Vector3(randf_range(-8, 8), 0, randf_range(-10, 10))
		box(n, Vector3(wd, h, wd), off + Vector3(0, h * 0.5, 0), M(c, Color.BLACK, 0, 0.5, 0.1, 0.35))
		for f in int(h / 4.0):
			box(n, Vector3(wd + 0.05, 0.4, wd + 0.05), off + Vector3(0, f * 4.0 + 2.5, 0), M(c.darkened(0.15), Color(0.6, 0.8, 1.0), 0.15, 0.2, 0.4))


# ---------------------------------------------------------------- 2 skate park
func _skate_side(z: float, s: float) -> float:
	var r := randf()
	if r < 0.35:
		_ramp(z, s)
		return randf_range(10.0, 14.0)
	if r < 0.62:
		var n := node(Vector3(s * randf_range(9.0, 16.0), 0, z), 4.0)
		_tree(n, Vector3.ZERO, randf_range(1.2, 1.8), [Color(0.35, 0.72, 0.35), Color(0.45, 0.8, 0.4), Color(0.3, 0.65, 0.4)])
		return randf_range(4.0, 8.0)
	if r < 0.85:
		var n2 := node(Vector3(s * 7.4, 0, z - 3.0), 3.5)
		box(n2, Vector3(0.4, 1.6, 7.0), Vector3(0, 0.8, 0), M(Color(0.8, 0.78, 0.75)), true)
		for k in 5:
			var c: Color = pick([Color(1, 0.4, 0.7), Color(0.3, 0.8, 0.9), Color(1, 0.85, 0.3), Color(0.5, 0.9, 0.4), Color(0.6, 0.4, 1.0)])
			var d := cyl(n2, randf_range(0.3, 0.8), 0.05, Vector3(-s * 0.21, randf_range(0.4, 1.3), randf_range(-3, 3)), M(c, c, 0.15, 0.8), Vector3(0, 0, PI / 2))
			d.scale.z *= randf_range(1.0, 2.5)
		return 8.0
	var n3 := node(Vector3(s * 7.0, 0, z), 2.0)
	_lamp(n3, Vector3.ZERO, s, Color(1, 0.95, 0.8), Color(0.3, 0.3, 0.35))
	cyl(n3, 0.35, 0.9, Vector3(0.5, 0.45, 1.0), M(Color(0.35, 0.45, 0.4), Color.BLACK, 0, 0.5, 0.5))
	return randf_range(5.0, 8.0)


func _ramp(z: float, s: float) -> void:
	# quarter-pipe rising away from the road, graffiti side panel, deck + railing
	var n := node(Vector3(s * randf_range(8.5, 11.0), 0, z - 4.0), 5.0)
	var rl := randf_range(6.0, 9.0)
	var rr := 3.6
	var skin: Color = pick([Color(0.3, 0.55, 0.9), Color(0.55, 0.4, 0.85), Color(0.25, 0.7, 0.75)])
	var surf := M(skin, Color.BLACK, 0, 0.6, 0.0, 0.25)
	var segs := 7
	for i in segs:
		var a := (float(i) + 0.5) / segs * (PI * 0.5)
		var pos := Vector3(s * rr * sin(a), rr - rr * cos(a), 0)
		box(n, Vector3(rr * PI * 0.5 / segs + 0.08, 0.18, rl), pos, surf, true, Vector3(0, 0, s * a))
	box(n, Vector3(0.3, rr, rl), Vector3(s * (rr + 0.15), rr * 0.5, 0), M(skin.darkened(0.35)), true)
	var panel := M(Color(0.95, 0.9, 0.8))
	box(n, Vector3(rr, rr * 0.9, 0.2), Vector3(s * rr * 0.62, rr * 0.45, rl * 0.5), panel, true)
	for k in 6:
		var c: Color = pick([Color(1, 0.4, 0.7), Color(0.3, 0.8, 0.9), Color(1, 0.85, 0.3), Color(0.5, 0.9, 0.4), Color(0.6, 0.4, 1.0)])
		var d := cyl(n, randf_range(0.35, 0.8), 0.05, Vector3(s * randf_range(0.8, rr), randf_range(0.5, rr * 0.8), rl * 0.5 + 0.12), M(c, c, 0.2, 0.7), Vector3(PI / 2, 0, 0))
		d.scale.x *= randf_range(1.0, 1.8)
	box(n, Vector3(1.6, 0.15, rl), Vector3(s * (rr + 0.8), rr, 0), M(Color(0.6, 0.45, 0.3)))
	var rail := M(Color(0.2, 0.2, 0.22), Color.BLACK, 0, 0.4, 0.6)
	for k in 3:
		box(n, Vector3(0.08, 1.2, 0.08), Vector3(s * (rr + 1.5), rr + 0.6, -rl * 0.5 + k * rl * 0.5), rail)
	box(n, Vector3(0.06, 0.06, rl), Vector3(s * (rr + 1.5), rr + 1.2, 0), rail)
	box(n, Vector3(0.12, 0.12, rl), Vector3(0, 0.06, 0), M(Color(0.85, 0.85, 0.9), Color.BLACK, 0, 0.3, 0.8))


func _tree(p: Node3D, pos: Vector3, sc: float, cols: Array) -> void:
	cyl(p, 0.3 * sc, 2.5 * sc, pos + Vector3(0, 1.25 * sc, 0), M(Color(0.45, 0.32, 0.22)))
	for k in 5:
		var c: Color = pick(cols)
		sph(p, randf_range(1.1, 1.6) * sc, pos + Vector3(randf_range(-1, 1) * sc, (2.8 + randf_range(0, 1.2)) * sc, randf_range(-1, 1) * sc), M(c, Color.BLACK, 0, 0.9, 0, 0.35))


func _pennants(z: float) -> void:
	var n := node(Vector3(0, 0, z), 1.0)
	for sd in [-1.0, 1.0]:
		cyl(n, 0.1, 7.0, Vector3(sd * 7.5, 3.5, 0), M(Color(0.3, 0.3, 0.35)))
	for i in 14:
		var t := float(i) / 13.0
		var x := -7.5 + 15.0 * t
		var y := 6.8 - 1.2 * sin(t * PI)
		var c: Color = [Color(1, 0.4, 0.6), Color(0.3, 0.75, 1), Color(1, 0.85, 0.3), Color(0.5, 0.9, 0.5)][i % 4]
		cone(n, 0.3, 0.7, Vector3(x, y - 0.35, 0), M(c, c, 0.2, 0.8), Vector3(PI, 0, 0))


func _skate_far(z: float, s: float) -> void:
	var n := node(Vector3(s * randf_range(24.0, 50.0), 0, z), 14.0)
	if randf() < 0.55:
		var m := M(Color(1.0, 0.85, 0.25), Color(1.0, 0.7, 0.1), 0.3, 0.4, 0.3, 0.3)
		var t: MeshInstance3D = w._torus(n, 9.0, 9.6, Vector3(0, 0, 0), m, Vector3(PI / 2, randf_range(-0.6, 0.6), 0))
		t.scale = Vector3(1.4, 1.0, 1.0)
		for k in 4:
			cyl(n, 0.25, 9.0, Vector3(-9.0 + k * 6.0, 4.5, 0), M(Color(0.95, 0.85, 0.5)))
	else:
		sph(n, randf_range(8.0, 14.0), Vector3(0, -2.0, 0), M(Color(0.45, 0.72, 0.4), Color.BLACK, 0, 0.95, 0, 0.3), 0.45)
		_tree(n, Vector3(randf_range(-4, 4), 2.0, 0), 1.6, [Color(0.3, 0.6, 0.35), Color(0.4, 0.72, 0.4)])


# ---------------------------------------------------------------- 3 neon rain alley
func _rain_side(z: float, s: float) -> float:
	if randf() < 0.82:
		return _shophouse(z, s, {"colors": [Color(0.2, 0.16, 0.22), Color(0.26, 0.2, 0.24), Color(0.18, 0.18, 0.26)],
			"night": true, "roof": "tile", "roof_c": Color(0.1, 0.1, 0.14), "sign": pick(["vertical", "vertical", "panel"]),
			"lanterns": true, "plants": true, "awning": false, "fmin": 2, "fmax": 3,
			"signs": [Color(1.0, 0.25, 0.7), Color(0.35, 0.55, 1.0), Color(0.75, 0.35, 1.0), Color(1.0, 0.45, 0.35)]})
	var n := node(Vector3(s * 7.0, 0.12, z), 2.0)
	for k in 6:
		var hgt := randf_range(3.0, 5.5)
		cyl(n, 0.06, hgt, Vector3(randf_range(-0.8, 0.8), hgt * 0.5, randf_range(-1, 1)), M(Color(0.2, 0.45, 0.3)))
	var ring_c: Color = pick([Color(1, 0.3, 0.7), Color(0.4, 0.6, 1)])
	w._torus(n, 0.7, 0.85, Vector3(-s * 0.8, 3.2, 0), G(ring_c, 3.5, 0.5), Vector3(0, PI / 2, 0))
	light(n, Vector3(-s * 1.5, 3.0, 0), ring_c, 2.0, 7.0)
	return randf_range(3.0, 5.0)


func _rain_far(z: float, s: float) -> void:
	var n := node(Vector3(s * randf_range(30.0, 70.0), 0, z), 20.0)
	var rock := M(Color(0.1, 0.13, 0.22), Color.BLACK, 0, 0.9, 0, 0.25)
	var hgt := randf_range(35.0, 70.0)
	cone(n, randf_range(12.0, 20.0), hgt, Vector3(0, hgt * 0.5 - 5.0, 0), rock)
	if randf() < 0.45:
		_pagoda(n, Vector3(0, hgt * 0.55, 0), 1.0, Color(0.9, 0.3, 1.0), true)


func _pagoda(p: Node3D, pos: Vector3, sc: float, glow: Color, night: bool) -> void:
	var body := M(Color(0.15, 0.12, 0.18), Color.BLACK, 0, 0.6)
	var roof := M(Color(0.12, 0.14, 0.2), Color.BLACK, 0, 0.5, 0.3)
	for i in 4:
		var wdt := (7.0 - i * 1.3) * sc
		var y := pos.y + i * 3.2 * sc
		box(p, Vector3(wdt * 0.7, 2.6 * sc, wdt * 0.7), Vector3(pos.x, y + 1.3 * sc, pos.z), body)
		box(p, Vector3(wdt * 0.66, 1.4 * sc, wdt * 0.02), Vector3(pos.x, y + 1.4 * sc, pos.z + wdt * 0.36), G(Color(1.0, 0.7, 0.4), 2.0 if night else 0.4))
		box(p, Vector3(wdt * 1.25, 0.35 * sc, wdt * 1.25), Vector3(pos.x, y + 2.75 * sc, pos.z), roof)
		box(p, Vector3(wdt * 1.3, 0.08 * sc, wdt * 1.3), Vector3(pos.x, y + 2.58 * sc, pos.z), G(glow, 3.0 if night else 0.8, 0.5))
		for cx in [-1.0, 1.0]:
			for cz in [-1.0, 1.0]:
				cone(p, 0.25 * sc, 1.0 * sc, Vector3(pos.x + cx * wdt * 0.62, y + 3.1 * sc, pos.z + cz * wdt * 0.62), roof, Vector3(cz * 0.5, 0, -cx * 0.5))
	cyl(p, 0.15 * sc, 4.0 * sc, Vector3(pos.x, pos.y + 14.5 * sc, pos.z), G(glow, 2.0))


# ---------------------------------------------------------------- 4 neon market
func _market_side(z: float, s: float) -> float:
	if randf() < 0.25:
		var pn := node(Vector3(s * randf_range(5.0, 7.0), 0.12, z), 1.0)
		_person(pn, Vector3.ZERO, randf() * TAU)
		if randf() < 0.5:
			_person(pn, Vector3(0.7, 0, 0.8), randf() * TAU)
		return randf_range(1.5, 3.0)
	var wd := randf_range(6.0, 8.5)
	var n := node(Vector3(s * 11.0, 0, z - wd * 0.5), wd)
	var floors := randi_range(3, 6)
	var y := 0.0
	var pal := [Color(0.42, 0.38, 0.52), Color(0.55, 0.45, 0.6), Color(0.85, 0.55, 0.7), Color(0.5, 0.5, 0.62), Color(0.95, 0.7, 0.75)]
	for f in floors:
		var fh := randf_range(2.8, 3.6)
		var dp := randf_range(5.5, 7.0)
		var off := randf_range(-0.8, 0.9) if f > 0 else 0.0
		var c: Color = pick(pal)
		var fxv := -s * (dp * 0.5) + (-s * off)
		box(n, Vector3(dp, fh, wd * randf_range(0.85, 1.0)), Vector3(-s * off, y + fh * 0.5, 0), M(c, Color.BLACK, 0, 0.8, 0, 0.3), f < 2)
		box(n, Vector3(dp + 0.2, 0.25, wd + 0.1), Vector3(-s * off, y + fh, 0), M(c.darkened(0.35)))
		if f == 0:
			box(n, Vector3(0.06, 2.0, wd * 0.6), Vector3(fxv - s * 0.02, 1.2, 0), w.mat(Color(1, 0.8, 0.55), Color(1, 0.75, 0.45), 1.2, 0.2))
			var ac2: Color = pick([Color(1, 0.4, 0.35), Color(0.3, 0.7, 0.9), Color(0.95, 0.75, 0.3)])
			box(n, Vector3(1.6, 0.12, wd * 0.7), Vector3(fxv - s * 0.8, 2.6, 0), M(ac2, ac2, 0.15), false, Vector3(0, 0, s * 0.3))
		else:
			for k in 2:
				var zz := -wd * 0.22 + k * wd * 0.44
				box(n, Vector3(0.06, 1.2, 1.4), Vector3(fxv - s * 0.02, y + fh * 0.55, zz), w.mat(Color(0.35, 0.3, 0.5), Color(0.5, 0.6, 1.0), 0.3, 0.2, 0.4))
			if randf() < 0.55:
				var sc: Color = pick([CYAN, PINK, Color(0.6, 0.45, 1.0)])
				var pw := randf_range(1.6, 3.0)
				box(n, Vector3(0.35, 1.0, pw + 0.2), Vector3(fxv - s * 0.3, y + fh * 0.5, randf_range(-1.0, 1.0)), M(Color(0.12, 0.1, 0.16)))
				box(n, Vector3(0.1, 0.8, pw), Vector3(fxv - s * 0.5, y + fh * 0.5, randf_range(-1.0, 1.0)), G(sc, 2.6, 0.5))
			if randf() < 0.5:
				var ay := y + fh * 0.3
				box(n, Vector3(0.6, 0.55, 0.85), Vector3(fxv - s * 0.3, ay, wd * 0.35), M(Color(0.88, 0.88, 0.92), Color.BLACK, 0, 0.4, 0.3))
				cyl(n, 0.2, 0.05, Vector3(fxv - s * 0.62, ay, wd * 0.35), M(Color(0.3, 0.3, 0.35)), Vector3(0, 0, PI / 2))
		y += fh
	cyl(n, 0.09, y, Vector3(-s * 3.2, y * 0.5, -wd * 0.45), M(Color(0.3, 0.3, 0.35), Color.BLACK, 0, 0.4, 0.6))
	if randf() < 0.5:
		sph(n, 0.7, Vector3(-s * 1.0, y + 0.6, 0), M(Color(0.3, 0.6, 0.4)))
	light(n, Vector3(-s * 4.8, 3.0, 0), pick([CYAN, PINK]), 1.4, 7.0)
	return wd + randf_range(0.0, 0.6)


func _power_lines(z: float) -> void:
	var n := node(Vector3(0, 0, z), 1.0)
	var pole := M(Color(0.35, 0.28, 0.25), Color.BLACK, 0, 0.8)
	for sd in [-1.0, 1.0]:
		cyl(n, 0.14, 8.5, Vector3(sd * 5.6, 4.25, 0), pole)
		box(n, Vector3(1.6, 0.12, 0.12), Vector3(sd * 5.6, 8.0, 0), pole)
		sph(n, 0.3, Vector3(sd * 5.6, 5.2, 0.25), G(Color(1, 0.3, 0.3), 2.0), 1.2)
	var wire := M(Color(0.1, 0.1, 0.12))
	for k in 3:
		var y := 7.9 - k * 0.35
		for i in 6:
			var t0 := float(i) / 6.0
			var t1 := float(i + 1) / 6.0
			var a := Vector3(-5.6 + 11.2 * t0, y - 0.9 * sin(t0 * PI), 0)
			var b := Vector3(-5.6 + 11.2 * t1, y - 0.9 * sin(t1 * PI), 0)
			var seg := box(n, Vector3((b - a).length(), 0.035, 0.035), (a + b) * 0.5, wire)
			seg.rotation.z = atan2(b.y - a.y, b.x - a.x)


func _market_far(z: float, s: float) -> void:
	var n := node(Vector3(s * randf_range(28.0, 60.0), 0, z), 15.0)
	var c: Color = pick([Color(0.95, 0.65, 0.8), Color(0.8, 0.6, 0.9), Color(0.7, 0.65, 0.95)])
	var hgt := randf_range(25.0, 55.0)
	box(n, Vector3(9.0, hgt, 9.0), Vector3(0, hgt * 0.5, 0), M(c, Color.BLACK, 0, 0.6, 0, 0.5))
	box(n, Vector3(6.0, hgt * 0.4, 6.0), Vector3(3.0, hgt + hgt * 0.2 - 4.0, 2.0), M(c.lightened(0.1), Color.BLACK, 0, 0.6, 0, 0.5))
	box(n, Vector3(9.1, 0.6, 9.1), Vector3(0, hgt * 0.7, 0), G(CYAN, 1.5, 0.5))


# ---------------------------------------------------------------- 5 hover harbor
func _harbor_side(z: float, s: float) -> float:
	var r := randf()
	var white := M(Color(0.95, 0.95, 1.0), Color.BLACK, 0, 0.25, 0.2, 0.35)
	if r < 0.4:
		var n := node(Vector3(s * randf_range(9.0, 22.0), randf_range(-2.0, 6.0), z), 6.0)
		var rad := randf_range(3.0, 5.5)
		cyl(n, rad, 0.8, Vector3.ZERO, white)
		cyl(n, rad * 1.02, 0.15, Vector3(0, 0.35, 0), G(pick([CYAN, Color(0.4, 1, 0.6), PINK]), 3.0, 0.8))
		cyl(n, rad * 0.7, 0.3, Vector3(0, -0.5, 0), M(Color(0.6, 0.62, 0.75), Color.BLACK, 0, 0.3, 0.6))
		for k in 3:
			var a := TAU * k / 3.0
			cone(n, 0.5, 1.4, Vector3(cos(a) * rad * 0.5, -1.2, sin(a) * rad * 0.5), G(CYAN, 4.0, 1.0), Vector3(PI, 0, 0))
		if randf() < 0.5:
			cyl(n, 1.0, 3.0, Vector3(0, 1.9, 0), M(Color(0.3, 0.8, 0.7), Color.BLACK, 0, 0.3, 0.2, 0.4))
			sph(n, 1.0, Vector3(0, 3.4, 0), G(Color(1, 0.85, 0.4), 1.5))
		w.bobbers.append([n, n.position.y, 0.5, randf_range(0.8, 1.4), randf() * TAU])
		return randf_range(8.0, 14.0)
	if r < 0.7:
		var n2 := node(Vector3(s * randf_range(6.5, 9.0), -6.0, z), 2.0)
		cyl(n2, 0.9, 10.0, Vector3(0, 5.0, 0), white)
		for k in 3:
			cyl(n2, 0.95, 0.25, Vector3(0, 6.5 + k * 1.1, 0), G(Color(1.0, 0.25, 0.3), 3.0, 1.0))
		sph(n2, 0.9, Vector3(0, 10.2, 0), white)
		return randf_range(6.0, 10.0)
	if r < 0.85:
		# crane
		var n3 := node(Vector3(s * randf_range(14.0, 24.0), -10.0, z), 12.0)
		var steel := M(Color(0.95, 0.45, 0.35), Color.BLACK, 0, 0.5, 0.4)
		var hgt := randf_range(26.0, 36.0)
		for cx in [-0.8, 0.8]:
			for cz in [-0.8, 0.8]:
				box(n3, Vector3(0.2, hgt, 0.2), Vector3(cx, hgt * 0.5, cz), steel)
		for k in int(hgt / 2.5):
			box(n3, Vector3(1.8, 0.12, 0.12), Vector3(0, k * 2.5, 0.8), steel, false, Vector3(0, 0, 0.8 if k % 2 == 0 else -0.8))
		var arm := Node3D.new()
		arm.position = Vector3(0, hgt, 0)
		arm.rotation.y = randf_range(-1.0, 1.0) + (PI if s > 0 else 0.0)
		n3.add_child(arm)
		box(arm, Vector3(22.0, 0.8, 0.8), Vector3(7.0, 0, 0), steel)
		box(arm, Vector3(3.0, 2.0, 2.0), Vector3(-4.0, -0.5, 0), M(Color(0.3, 0.3, 0.35)))
		box(arm, Vector3(0.05, 8.0, 0.05), Vector3(15.0, -4.0, 0), M(Color(0.2, 0.2, 0.2)))
		box(arm, Vector3(2.0, 1.4, 2.0), Vector3(15.0, -8.5, 0), M(Color(0.95, 0.8, 0.3)))
		w.spinners.append([arm, Vector3(0, 1, 0), 0.08])
		return randf_range(18.0, 26.0)
	var n4 := node(Vector3(s * randf_range(16.0, 26.0), 0, z), 8.0)
	_capsule_pod(n4, s)
	return randf_range(10.0, 16.0)


func _capsule_pod(n: Node3D, s: float) -> void:
	n.position.y = randf_range(4.0, 9.0)
	var body := M(Color(0.95, 0.98, 1.0), Color.BLACK, 0, 0.2, 0.2, 0.4)
	var c := sph(n, 1.5, Vector3.ZERO, body)
	c.scale = Vector3(1.6, 1.0, 3.2)
	sph(n, 1.1, Vector3(0, 0.5, -1.5), M(Color(0.3, 0.8, 0.8), Color(0.2, 0.6, 0.8), 0.4, 0.1, 0.5, 0.5), 0.7)
	var ring: MeshInstance3D = w._torus(n, 2.3, 2.5, Vector3.ZERO, G(Color(0.4, 1.0, 0.6), 3.0, 0.8), Vector3.ZERO)
	ring.scale = Vector3(1.0, 1.0, 1.6)
	w.bobbers.append([n, n.position.y, 0.6, randf_range(0.6, 1.1), randf() * TAU])


func _light_ring(z: float) -> void:
	var n := node(Vector3(0, 0, z), 1.0)
	var c: Color = pick([CYAN, Color(0.4, 1.0, 0.6), PINK])
	w._torus(n, 6.2, 6.5, Vector3(0, 2.0, 0), G(c, 3.0, 1.0), Vector3(PI / 2, 0, 0))
	for k in 6:
		var a := TAU * k / 6.0
		sph(n, 0.3, Vector3(cos(a) * 6.35, 2.0 + sin(a) * 6.35, 0), G(Color.WHITE, 4.0, 1.0))


func _harbor_far(z: float, s: float) -> void:
	var n := node(Vector3(s * randf_range(30.0, 70.0), -20.0, z), 15.0)
	var hgt := randf_range(40.0, 75.0)
	var c: Color = pick([Color(0.95, 0.85, 0.95), Color(0.85, 0.95, 1.0), Color(1.0, 0.9, 0.8)])
	cyl(n, randf_range(4.0, 7.0), hgt, Vector3(0, hgt * 0.5, 0), M(c, Color.BLACK, 0, 0.3, 0.2, 0.45))
	for k in int(hgt / 6.0):
		var sc: Color = [CYAN, Color(0.4, 1, 0.6), PINK, Color(1, 0.8, 0.3)][k % 4]
		cyl(n, randf_range(4.2, 7.2), 0.5, Vector3(0, k * 6.0 + 3.0, 0), G(sc, 1.8, 0.4))
	sph(n, 5.0, Vector3(0, hgt, 0), M(c, Color.BLACK, 0, 0.3, 0.2, 0.45), 0.6)
	w._beam(n, Vector3(0, hgt, 0), 1.0, 40.0, CYAN, 0.25)


# ---------------------------------------------------------------- 6 sakura heights
func _sakura_side(z: float, s: float) -> float:
	var r := randf()
	if r < 0.42:
		var n := node(Vector3(s * randf_range(7.0, 13.0), 0, z), 4.0)
		_blossom_tree(n, Vector3.ZERO, randf_range(1.0, 1.6))
		return randf_range(4.0, 7.0)
	if r < 0.75:
		var wd := randf_range(7.0, 10.0)
		var n2 := node(Vector3(s * 12.5, 0, z - wd * 0.5), wd)
		var wall := M(Color(0.96, 0.94, 0.9), Color.BLACK, 0, 0.9, 0, 0.2)
		var beam := M(Color(0.3, 0.2, 0.16), Color.BLACK, 0, 0.8)
		var roof := M(Color(0.2, 0.3, 0.33), Color.BLACK, 0, 0.5, 0.2, 0.2)
		box(n2, Vector3(6.0, 3.4, wd), Vector3(0, 1.9, 0), wall, true)
		box(n2, Vector3(6.4, 0.5, wd + 0.4), Vector3(0, 0.25, 0), M(Color(0.5, 0.45, 0.42)))
		for k in int(wd / 1.6) + 1:
			box(n2, Vector3(0.1, 3.4, 0.18), Vector3(-s * 3.02, 1.9, -wd * 0.5 + k * 1.6), beam)
		box(n2, Vector3(0.1, 0.2, wd), Vector3(-s * 3.02, 3.0, 0), beam)
		box(n2, Vector3(0.05, 1.6, wd * 0.5), Vector3(-s * 3.05, 1.7, 0), w.mat(Color(1.0, 0.92, 0.75), Color(1.0, 0.8, 0.5), 0.5, 0.8))
		box(n2, Vector3(4.6, 0.3, wd + 1.4), Vector3(-s * 1.7, 4.2, 0), roof, true, Vector3(0, 0, s * 0.5))
		box(n2, Vector3(4.6, 0.3, wd + 1.4), Vector3(s * 1.7, 4.2, 0), roof, true, Vector3(0, 0, -s * 0.5))
		box(n2, Vector3(0.4, 0.4, wd + 1.6), Vector3(0, 5.3, 0), roof)
		return wd + randf_range(2.0, 5.0)
	var n3 := node(Vector3(s * 6.4, 0.12, z), 1.5)
	var stone := M(Color(0.62, 0.62, 0.6), Color.BLACK, 0, 0.95)
	box(n3, Vector3(0.7, 0.3, 0.7), Vector3(0, 0.15, 0), stone)
	cyl(n3, 0.14, 1.0, Vector3(0, 0.8, 0), stone)
	box(n3, Vector3(0.6, 0.55, 0.6), Vector3(0, 1.55, 0), stone)
	box(n3, Vector3(0.45, 0.35, 0.62), Vector3(0, 1.55, 0), G(Color(1.0, 0.75, 0.4), 2.0, 0.3))
	cone(n3, 0.55, 0.45, Vector3(0, 2.05, 0), stone)
	for k in 5:
		var hgt := randf_range(3.0, 6.0)
		cyl(n3, 0.07, hgt, Vector3(s * randf_range(1.0, 2.2), hgt * 0.5, randf_range(-1, 1)), M(Color(0.45, 0.7, 0.35)))
	return randf_range(4.0, 7.0)


func _blossom_tree(p: Node3D, pos: Vector3, sc: float) -> void:
	var bark := M(Color(0.3, 0.2, 0.2))
	cyl(p, 0.3 * sc, 3.0 * sc, pos + Vector3(0, 1.5 * sc, 0), bark)
	box(p, Vector3(0.25, 2.0, 0.25) * sc, pos + Vector3(0.6 * sc, 3.3 * sc, 0), bark, false, Vector3(0, 0, -0.6))
	box(p, Vector3(0.25, 2.0, 0.25) * sc, pos + Vector3(-0.6 * sc, 3.3 * sc, 0.2), bark, false, Vector3(0, 0, 0.6))
	for k in 6:
		var c: Color = pick([Color(1.0, 0.75, 0.85), Color(1.0, 0.85, 0.92), Color(0.98, 0.65, 0.8)])
		sph(p, randf_range(1.0, 1.5) * sc, pos + Vector3(randf_range(-1.6, 1.6) * sc, (3.8 + randf_range(0, 1.4)) * sc, randf_range(-1.2, 1.2) * sc), M(c, c, 0.12, 0.9, 0, 0.45))


func _torii(z: float, sc: float) -> void:
	var n := node(Vector3(0, 0, z), 1.0)
	var red := M(Color(0.9, 0.22, 0.18), Color(0.6, 0.1, 0.05), 0.15, 0.6)
	var black := M(Color(0.08, 0.07, 0.08))
	var half := 5.4 * sc
	for sd in [-1.0, 1.0]:
		cyl(n, 0.4 * sc, 7.5 * sc, Vector3(sd * half, 3.75 * sc, 0), red)
		cyl(n, 0.5 * sc, 0.5 * sc, Vector3(sd * half, 0.25 * sc, 0), black)
	box(n, Vector3(half * 2.0 + 1.2, 0.5 * sc, 0.5 * sc), Vector3(0, 6.2 * sc, 0), red, true)
	box(n, Vector3(half * 2.0 + 3.0, 0.45 * sc, 0.8 * sc), Vector3(0, 7.6 * sc, 0), red, true)
	box(n, Vector3(half * 2.0 + 3.4, 0.25 * sc, 0.9 * sc), Vector3(0, 7.95 * sc, 0), black)
	box(n, Vector3(0.4 * sc, 1.4 * sc, 0.3 * sc), Vector3(0, 6.9 * sc, 0), black)
	sph(n, 0.35, Vector3(-half + 1.0, 5.4 * sc, 0.4), G(Color(1.0, 0.7, 0.4), 2.5), 1.3)
	sph(n, 0.35, Vector3(half - 1.0, 5.4 * sc, 0.4), G(Color(1.0, 0.7, 0.4), 2.5), 1.3)


func _sakura_far(z: float, s: float) -> void:
	var n := node(Vector3(s * randf_range(35.0, 75.0), -4.0, z), 20.0)
	var hgt := randf_range(30.0, 60.0)
	var rad := randf_range(18.0, 28.0)
	cone(n, rad, hgt, Vector3(0, hgt * 0.5, 0), M(Color(0.55, 0.55, 0.75), Color.BLACK, 0, 0.9, 0, 0.3))
	cone(n, rad * 0.32, hgt * 0.32, Vector3(0, hgt * 0.84, 0), M(Color(0.98, 0.97, 1.0), Color.BLACK, 0, 0.8, 0, 0.4))
	if randf() < 0.3:
		_pagoda(n, Vector3(rad * 0.4, 0, rad * 0.4), 0.9, Color(1.0, 0.6, 0.7), false)


# ---------------------------------------------------------------- 7 candy carnival
func _carnival_side(z: float, s: float) -> float:
	var r := randf()
	var n := node(Vector3(s * randf_range(7.5, 12.0), 0, z), 4.0)
	if r < 0.35:
		# striped tent
		var a: Color = pick([Color(1, 0.35, 0.4), Color(0.35, 0.6, 1.0), Color(0.6, 0.35, 0.9), Color(1, 0.65, 0.2)])
		var rad := randf_range(2.2, 3.4)
		for k in 6:
			var c := a if k % 2 == 0 else Color(0.98, 0.96, 0.92)
			var seg := cyl(n, rad, 0.45, Vector3(0, 0.25 + k * 0.45, 0), M(c, c, 0.05, 0.8))
			seg.scale.x = rad
		cone(n, rad * 1.15, 2.2, Vector3(0, 3.8, 0), M(a, a, 0.1, 0.8))
		cone(n, rad * 0.6, 1.2, Vector3(0, 4.9, 0), M(Color(0.98, 0.96, 0.92)))
		cyl(n, 0.05, 1.2, Vector3(0, 6.0, 0), M(Color(0.9, 0.8, 0.3)))
		box(n, Vector3(0.6, 0.35, 0.02), Vector3(0, 6.4, 0.3), G(Color(1, 0.85, 0.3), 1.5))
		light(n, Vector3(-s * rad, 1.5, 0), Color(1, 0.7, 0.4), 1.5, 7.0)
		return randf_range(7.0, 10.0)
	if r < 0.55:
		for k in randi_range(4, 8):
			var c2: Color = pick([Color(1, 0.4, 0.5), Color(0.4, 0.8, 1), Color(1, 0.85, 0.3), Color(0.6, 1, 0.5), Color(0.8, 0.5, 1)])
			var bp := Vector3(randf_range(-0.8, 0.8), randf_range(3.5, 5.0), randf_range(-0.8, 0.8))
			sph(n, 0.45, bp, M(c2, c2, 0.3, 0.2, 0, 0.6), 1.2)
			box(n, Vector3(0.02, bp.y - 1.0, 0.02), Vector3(bp.x * 0.3, (bp.y - 1.0) * 0.5 + 1.0, bp.z * 0.3), M(Color.WHITE))
		box(n, Vector3(1.4, 1.0, 1.0), Vector3(0, 0.5, 0), M(Color(0.95, 0.5, 0.6)))
		w.bobbers.append([n, 0.0, 0.2, 1.2, randf() * TAU])
		return randf_range(4.0, 6.0)
	if r < 0.78:
		# giant lollipop
		var hgt := randf_range(4.0, 7.0)
		cyl(n, 0.15, hgt, Vector3(0, hgt * 0.5, 0), M(Color(0.98, 0.96, 0.95)))
		var cols := [Color(1, 0.35, 0.5), Color(0.98, 0.95, 0.9), Color(0.5, 0.8, 1.0), Color(1, 0.85, 0.3)]
		var base: Color = pick(cols)
		cyl(n, 1.6, 0.3, Vector3(0, hgt + 1.4, 0), M(base, base, 0.2, 0.3, 0, 0.5), Vector3(PI / 2, 0, 0))
		for k in 3:
			w._torus(n, 0.4 + k * 0.4, 0.55 + k * 0.4, Vector3(0, hgt + 1.4, 0.16), M(Color(0.98, 0.95, 0.92), Color.BLACK, 0, 0.3), Vector3(PI / 2, 0, 0))
		return randf_range(4.0, 7.0)
	# candy cane + lamp
	var red := M(Color(1, 0.25, 0.3), Color.BLACK, 0, 0.3, 0, 0.4)
	var wht := M(Color(0.98, 0.96, 0.95), Color.BLACK, 0, 0.3, 0, 0.4)
	for k in 8:
		cyl(n, 0.3, 0.6, Vector3(0, 0.3 + k * 0.6, 0), red if k % 2 == 0 else wht)
	w._torus(n, 0.9, 1.5, Vector3(-s * 0.6, 4.8, 0), red, Vector3(PI / 2, 0, 0))
	_lamp(n, Vector3(-s * 1.5, 0, 2.0), s, Color(1, 0.85, 0.5), Color(0.9, 0.3, 0.35), true)
	return randf_range(5.0, 8.0)


func _bulb_string(z: float) -> void:
	var n := node(Vector3(0, 0, z), 1.0)
	for i in 13:
		var t := float(i) / 12.0
		var x := -7.0 + 14.0 * t
		var y := 6.6 - 1.1 * sin(t * PI)
		var c: Color = [Color(1, 0.85, 0.4), Color(1, 0.4, 0.5), Color(0.5, 0.9, 1), Color(0.7, 1, 0.5)][i % 4]
		sph(n, 0.16, Vector3(x, y, 0), G(c, 4.5, 1.2))
	for i in 6:
		var t0 := float(i) / 6.0
		var t1 := float(i + 1) / 6.0
		var a := Vector3(-7.0 + 14.0 * t0, 6.7 - 1.1 * sin(t0 * PI), 0)
		var b := Vector3(-7.0 + 14.0 * t1, 6.7 - 1.1 * sin(t1 * PI), 0)
		var seg := box(n, Vector3((b - a).length(), 0.03, 0.03), (a + b) * 0.5, M(Color(0.15, 0.12, 0.15)))
		seg.rotation.z = atan2(b.y - a.y, b.x - a.x)


func _carnival_far(z: float, s: float) -> void:
	var n := node(Vector3(s * randf_range(28.0, 55.0), 0, z), 18.0)
	if randf() < 0.5:
		# ferris wheel
		var wheel := Node3D.new()
		wheel.position = Vector3(0, 18.0, 0)
		wheel.rotation.y = s * 0.6
		n.add_child(wheel)
		var rim := G(Color(1, 0.6, 0.8), 2.2, 1.0)
		var spin := Node3D.new()
		wheel.add_child(spin)
		w._torus(spin, 13.5, 14.0, Vector3.ZERO, rim, Vector3(PI / 2, 0, 0))
		w._torus(spin, 6.0, 6.4, Vector3.ZERO, G(Color(0.5, 0.9, 1.0), 2.0, 1.0), Vector3(PI / 2, 0, 0))
		for k in 12:
			var a := TAU * k / 12.0
			box(spin, Vector3(0.15, 14.0, 0.15), Vector3(cos(a) * 7.0, sin(a) * 7.0, 0), M(Color(0.95, 0.95, 1.0)), false, Vector3(0, 0, a - PI / 2))
			var cab: Color = [Color(1, 0.4, 0.5), Color(1, 0.85, 0.3), Color(0.4, 0.8, 1), Color(0.6, 1, 0.5)][k % 4]
			box(spin, Vector3(1.4, 1.4, 1.4), Vector3(cos(a) * 14.2, sin(a) * 14.2, 0), M(cab, cab, 0.4))
		w.spinners.append([spin, Vector3(0, 0, 1), 0.25])
		for sd in [-1.0, 1.0]:
			box(wheel, Vector3(0.6, 20.0, 0.6), Vector3(sd * 5.0, -8.0, 0), M(Color(0.9, 0.9, 0.95)), false, Vector3(0, 0, sd * 0.25))
	else:
		var m := G(Color(1.0, 0.4, 0.6), 1.2, 0.5)
		w._torus(n, 8.0, 8.6, Vector3(0, 9.0, 0), m, Vector3(PI / 2, s * 0.8, 0))
		for k in 5:
			cyl(n, 0.3, 10.0, Vector3(-12.0 + k * 6.0, 5.0, 0), M(Color(0.9, 0.85, 0.95)))
		box(n, Vector3(30.0, 0.6, 1.2), Vector3(0, 10.0, 0), m)
