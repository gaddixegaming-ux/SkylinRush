extends Node3D
## Skyline Rush - game director: state, input, 8 abilities, flow meter,
## power cores, collisions, scoring, sky zones and game-feel (hitstop, slow-mo).

const WorldScript := preload("res://scripts/world.gd")
const PlayerScript := preload("res://scripts/player.gd")
const CamScript := preload("res://scripts/camera_rig.gd")
const HudScript := preload("res://scripts/hud.gd")
const AudioScript := preload("res://scripts/audio.gd")
const FxScript := preload("res://scripts/fx.gd")
const ThemesScript := preload("res://scripts/themes.gd")
const RigScript := preload("res://characters/character_rig.gd")

const LANE_WIDTH := 2.5
const START_SPEED := 16.0
const MAX_SPEED := 44.0
const SPEED_GAIN := 0.3
const MENU_SPEED := 9.0
const SAVE_PATH := "user://skyline_rush.cfg"
const ZONE_LEN := 750.0

const PINK := Color(1.0, 0.35, 0.75)
const CYAN := Color(0.35, 0.9, 1.0)
const GOLD := Color(1.0, 0.8, 0.25)
const GREEN := Color(0.4, 1.0, 0.6)

const ABILITIES := [
	{"id": "dash", "name": "DASH", "key": "SHIFT", "cd": 2.5, "dur": 0.45, "color": Color(1.0, 0.35, 0.75)},
	{"id": "airdash", "name": "AIR DASH", "key": "SHIFT", "cd": 0.6, "dur": 0.28, "color": Color(1.0, 0.6, 0.9)},
	{"id": "wallrun", "name": "WALL RUN", "key": "Q", "cd": 1.0, "dur": 3.0, "color": Color(0.45, 0.7, 1.0)},
	{"id": "grapple", "name": "GRAPPLE", "key": "E", "cd": 1.0, "dur": 1.0, "color": Color(0.4, 1.0, 0.6)},
	{"id": "timeshift", "name": "TIME SHIFT", "key": "R", "cd": 14.0, "dur": 3.0, "color": Color(0.65, 0.6, 1.0)},
	{"id": "phase", "name": "PHASE", "key": "F", "cd": 7.0, "dur": 1.0, "color": Color(0.35, 0.9, 1.0)},
	{"id": "magnet", "name": "MAGNET PULL", "key": "C", "cd": 9.0, "dur": 0.9, "color": Color(1.0, 0.45, 0.45)},
	{"id": "slam", "name": "GROUND SLAM", "key": "S", "cd": 3.5, "dur": 0.0, "color": Color(1.0, 0.8, 0.25)},
]
const DASH := 0
const AIRDASH := 1
const WALL := 2
const GRAPPLE := 3
const TIMESHIFT := 4
const PHASE := 5
const MAGNET := 6
const SLAM := 7

const ZONES := [
	{"name": "SKY ROADS", "top": Color(0.42, 0.52, 0.98), "hor": Color(1.0, 0.74, 0.92), "fog": Color(0.98, 0.8, 0.96),
		"sun": Color(1.0, 0.92, 0.95), "sun_e": 1.2, "amb": 1.0, "stars": 0.0, "ground": Color(0.6, 0.4, 0.8), "fog_d": 0.011, "plight": 0.0, "fx": "none", "wet": false},
	{"name": "LANTERN FESTIVAL", "top": Color(0.3, 0.62, 1.0), "hor": Color(0.86, 0.93, 1.0), "fog": Color(0.86, 0.9, 1.0),
		"sun": Color(1.0, 0.95, 0.85), "sun_e": 1.35, "amb": 1.1, "stars": 0.0, "ground": Color(0.8, 0.75, 0.7), "fog_d": 0.009, "plight": 0.0, "fx": "confetti", "wet": false},
	{"name": "SKATE PARK", "top": Color(0.15, 0.55, 1.0), "hor": Color(0.72, 0.9, 1.0), "fog": Color(0.8, 0.91, 1.0),
		"sun": Color(1.0, 0.97, 0.88), "sun_e": 1.2, "amb": 0.95, "stars": 0.0, "ground": Color(0.8, 0.85, 0.7), "fog_d": 0.007, "plight": 0.0, "fx": "none", "wet": false},
	{"name": "NEON RAIN ALLEY", "top": Color(0.02, 0.03, 0.1), "hor": Color(0.15, 0.22, 0.5), "fog": Color(0.14, 0.18, 0.42),
		"sun": Color(0.5, 0.6, 1.0), "sun_e": 0.25, "amb": 0.45, "stars": 0.0, "ground": Color(0.05, 0.06, 0.15), "fog_d": 0.022, "plight": 1.3, "fx": "rain", "wet": true},
	{"name": "NEON MARKET", "top": Color(0.42, 0.5, 0.95), "hor": Color(0.98, 0.75, 0.9), "fog": Color(0.88, 0.76, 0.95),
		"sun": Color(1.0, 0.85, 0.9), "sun_e": 1.0, "amb": 0.95, "stars": 0.0, "ground": Color(0.5, 0.4, 0.6), "fog_d": 0.012, "plight": 0.3, "fx": "sparks", "wet": false},
	{"name": "HOVER HARBOR", "top": Color(0.3, 0.42, 0.85), "hor": Color(1.0, 0.78, 0.58), "fog": Color(1.0, 0.8, 0.68),
		"sun": Color(1.0, 0.78, 0.55), "sun_e": 1.3, "amb": 1.0, "stars": 0.0, "ground": Color(0.8, 0.6, 0.7), "fog_d": 0.01, "plight": 0.0, "fx": "none", "wet": false},
	{"name": "SAKURA HEIGHTS", "top": Color(0.5, 0.62, 1.0), "hor": Color(1.0, 0.86, 0.9), "fog": Color(1.0, 0.88, 0.93),
		"sun": Color(1.0, 0.93, 0.9), "sun_e": 1.2, "amb": 1.05, "stars": 0.0, "ground": Color(0.7, 0.75, 0.6), "fog_d": 0.01, "plight": 0.0, "fx": "petals", "wet": false},
	{"name": "CANDY CARNIVAL", "top": Color(0.22, 0.18, 0.5), "hor": Color(1.0, 0.55, 0.5), "fog": Color(0.9, 0.55, 0.62),
		"sun": Color(1.0, 0.65, 0.55), "sun_e": 0.8, "amb": 0.8, "stars": 0.4, "ground": Color(0.45, 0.3, 0.45), "fog_d": 0.013, "plight": 0.8, "fx": "sparks", "wet": false},
]
const ZONE_LOOKAHEAD := 215.0

enum State { MENU, PLAYING, PAUSED, DEAD }

var state: State = State.MENU
var world
var player
var cam
var hud
var audio
var fx
var speed_lines: CPUParticles3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var sun: DirectionalLight3D
var stars_mat: StandardMaterial3D

var speed := START_SPEED
var distance := 0.0
var score := 0.0
var gold := 0
var close_calls := 0
var best_score := 0
var ab_cd: Array[float] = []
var ab_active: Array[float] = []
var cores: Array = []
var flow := 0.0
var flow_idle := 0.0
var flow_tier := 0
var score_boost_t := 0.0
var wall_active := false
var grapple_active := false
var dashjump_carry := false
var grace := 0.0
var stumble_timer := 0.0
var portal_boost := 0.0
var dead_timer := 0.0
var death_title := ""
var new_best := false
var slowmo_left := 0.0
var curve := Vector2(0.0008, -0.0004)
var curve_target := Vector2.ZERO
var curve_timer := 0.0
var beat := 0.0
var coin_streak := 0
var coin_streak_t := 0.0
var last_km := 0
var zone_idx := 0
var zone_from: Dictionary = {}
var zone_cur: Dictionary = {}
var zone_t := 1.0
var shift_amount := 0.0
var phase_amount := 0.0
var wall_hint_t := 0.0
var start_zone := 0
var char_idx := 1
var zone_start := 0.0
var warp_t := 0.0
var warp_target := -1
var warped := false
var weather: CPUParticles3D
var weather_mat: StandardMaterial3D
var player_light: OmniLight3D
var board_t := 0.0
var grind_t := 0.0
var grind_fx_t := 0.0
var on_rail := false
var revive_cost := 100
var revive_bridge_t := 0.0
var last_hit := ""


# ============================================================ setup
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	randomize()
	_setup_input()
	_load()
	_build_env()

	world = WorldScript.new()
	add_child(world)
	fx = FxScript.new()
	add_child(fx)
	player = PlayerScript.new()
	add_child(player)
	player.jumped.connect(_on_jumped)
	player.landed.connect(_on_landed)
	player.slid.connect(func(): audio.play("slide", randf_range(0.95, 1.05), -4.0))
	player.grapple_released.connect(_on_grapple_released)
	player_light = OmniLight3D.new()
	player_light.position = Vector3(0, 2.6, 1.8)
	player_light.light_color = Color(1.0, 0.85, 0.75)
	player_light.omni_range = 9.0
	player_light.light_energy = 0.0
	player.add_child(player_light)

	cam = CamScript.new()
	add_child(cam)
	cam.current = true
	_build_speed_lines()
	_build_weather()

	audio = AudioScript.new()
	add_child(audio)

	hud = HudScript.new()
	add_child(hud)
	hud.setup_abilities(ABILITIES)
	hud.play_pressed.connect(_start_game)
	hud.retry_pressed.connect(_start_game)
	hud.menu_pressed.connect(_enter_menu)
	hud.resume_pressed.connect(func(): _set_paused(false))
	hud.quit_pressed.connect(func(): get_tree().quit())
	hud.track_changed.connect(_select_track)
	hud.revive_pressed.connect(_revive)
	hud.char_changed.connect(_select_char)

	for n in [world, fx, player, cam]:
		n.process_mode = Node.PROCESS_MODE_PAUSABLE
	for i in ABILITIES.size():
		ab_cd.append(0.0)
		ab_active.append(0.0)
	zone_cur = ZONES[0].duplicate()
	_apply_zone(zone_cur)
	_enter_menu()


func _build_env() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_curve = 0.12
	sky_mat.sun_angle_max = 30.0
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_white = 6.0
	env.glow_enabled = true
	env.glow_intensity = 0.9
	env.glow_strength = 1.0
	env.glow_bloom = 0.06
	env.glow_hdr_threshold = 0.95
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	env.fog_enabled = true
	env.fog_density = 0.011
	env.fog_aerial_perspective = 0.3
	env.fog_sky_affect = 0.25
	env.ssao_enabled = true
	env.ssao_intensity = 1.2
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.15
	env.adjustment_contrast = 1.05
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-42, -35, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 80.0
	add_child(sun)
	var fill := DirectionalLight3D.new()
	fill.rotation_degrees = Vector3(-20, 150, 0)
	fill.light_color = Color(0.7, 0.6, 1.0)
	fill.light_energy = 0.35
	fill.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_ONLY
	add_child(fill)

	# star field for the night zones
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var sm := SphereMesh.new()
	sm.radius = 0.9
	sm.height = 1.8
	sm.radial_segments = 6
	sm.rings = 3
	mm.mesh = sm
	mm.instance_count = 700
	for i in mm.instance_count:
		var dir := Vector3(randf_range(-1, 1), randf_range(0.08, 1.0), randf_range(-1, 0.3)).normalized()
		var s := randf_range(0.4, 1.3)
		mm.set_instance_transform(i, Transform3D(Basis().scaled(Vector3(s, s, s)), dir * 420.0))
	var stars := MultiMeshInstance3D.new()
	stars.multimesh = mm
	stars_mat = StandardMaterial3D.new()
	stars_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	stars_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	stars_mat.disable_fog = true
	stars_mat.albedo_color = Color(1.4, 1.3, 1.6, 0.0)
	stars.material_override = stars_mat
	stars.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(stars)


func _build_speed_lines() -> void:
	speed_lines = CPUParticles3D.new()
	speed_lines.amount = 110
	speed_lines.lifetime = 0.45
	speed_lines.local_coords = true
	speed_lines.emission_shape = CPUParticles3D.EMISSION_SHAPE_RING
	speed_lines.emission_ring_axis = Vector3(0, 0, 1)
	speed_lines.emission_ring_radius = 9.0
	speed_lines.emission_ring_inner_radius = 4.0
	speed_lines.emission_ring_height = 1.0
	speed_lines.position = Vector3(0, 0, -28)
	speed_lines.direction = Vector3(0, 0, 1)
	speed_lines.spread = 1.0
	speed_lines.gravity = Vector3.ZERO
	speed_lines.initial_velocity_min = 70.0
	speed_lines.initial_velocity_max = 95.0
	var bm := BoxMesh.new()
	bm.size = Vector3(0.035, 0.035, 4.0)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(1.0, 0.95, 1.0, 0.45)
	bm.material = m
	speed_lines.mesh = bm
	speed_lines.emitting = false
	cam.add_child(speed_lines)


func _build_weather() -> void:
	weather = CPUParticles3D.new()
	weather.local_coords = true
	weather.emitting = false
	weather_mat = StandardMaterial3D.new()
	weather_mat.vertex_color_use_as_albedo = true
	weather_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	weather_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	cam.add_child(weather)


func _set_weather(kind: String, wet: bool) -> void:
	env.ssr_enabled = wet
	env.ssr_max_steps = 48
	weather.emitting = false
	if kind == "none":
		return
	var bm := BoxMesh.new()
	var grad := Gradient.new()
	weather.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	weather.gravity = Vector3.ZERO
	weather.spread = 12.0
	weather_mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
	match kind:
		"rain":
			bm.size = Vector3(0.025, 0.9, 0.025)
			weather.amount = 700
			weather.lifetime = 0.55
			weather.position = Vector3(0, 9.0, -9.0)
			weather.emission_box_extents = Vector3(16, 1, 14)
			weather.direction = Vector3(0, -1, 0.25)
			weather.spread = 2.0
			weather.initial_velocity_min = 30.0
			weather.initial_velocity_max = 40.0
			weather_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			grad.set_color(0, Color(0.6, 0.7, 1.0, 0.45))
			grad.set_color(1, Color(0.8, 0.8, 1.0, 0.35))
		"confetti", "petals":
			bm.size = Vector3(0.14, 0.02, 0.1)
			weather.amount = 160
			weather.lifetime = 3.0
			weather.position = Vector3(0, 7.0, -14.0)
			weather.emission_box_extents = Vector3(16, 3, 12)
			weather.direction = Vector3(0.2, -0.4, 1.0)
			weather.initial_velocity_min = 4.0
			weather.initial_velocity_max = 8.0
			weather.gravity = Vector3(0.5, -1.2, 0)
			weather.angular_velocity_min = -200.0
			weather.angular_velocity_max = 200.0
			if kind == "petals":
				grad.set_color(0, Color(1.0, 0.75, 0.85))
				grad.set_color(1, Color(1.0, 0.9, 0.95))
			else:
				grad.set_color(0, Color(1.0, 0.4, 0.5))
				grad.add_point(0.33, Color(0.4, 0.8, 1.0))
				grad.add_point(0.66, Color(1.0, 0.85, 0.3))
				grad.set_color(grad.get_point_count() - 1, Color(0.6, 1.0, 0.6))
		"sparks":
			bm.size = Vector3(0.07, 0.07, 0.07)
			weather.amount = 90
			weather.lifetime = 3.0
			weather.position = Vector3(0, 1.0, -12.0)
			weather.emission_box_extents = Vector3(14, 3, 12)
			weather.direction = Vector3(0, 1, 0.6)
			weather.initial_velocity_min = 1.0
			weather.initial_velocity_max = 3.0
			weather_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			grad.set_color(0, Color(2.0, 1.4, 0.6, 0.9))
			grad.set_color(1, Color(2.0, 0.8, 1.6, 0.9))
	bm.material = weather_mat
	weather.mesh = bm
	weather.color_initial_ramp = grad
	weather.emitting = true


# ============================================================ input
func _setup_input() -> void:
	var keys := {
		"left": [KEY_A, KEY_LEFT], "right": [KEY_D, KEY_RIGHT],
		"jump": [KEY_W, KEY_UP, KEY_SPACE], "slide": [KEY_S, KEY_DOWN, KEY_CTRL],
		"ab_dash": [KEY_SHIFT, KEY_1], "ab_wall": [KEY_Q, KEY_2], "ab_grapple": [KEY_E, KEY_3],
		"ab_time": [KEY_R, KEY_4], "ab_phase": [KEY_F, KEY_5], "ab_magnet": [KEY_C, KEY_6],
		"pause": [KEY_ESCAPE, KEY_P], "confirm": [KEY_ENTER, KEY_SPACE],
		"music": [KEY_M], "fullscreen": [KEY_F11], "controls": [KEY_TAB],
	}
	var pads := {
		"left": [JOY_BUTTON_DPAD_LEFT], "right": [JOY_BUTTON_DPAD_RIGHT],
		"jump": [JOY_BUTTON_A], "slide": [JOY_BUTTON_B], "ab_dash": [JOY_BUTTON_RIGHT_SHOULDER],
		"ab_wall": [JOY_BUTTON_LEFT_SHOULDER], "ab_grapple": [JOY_BUTTON_X], "ab_phase": [JOY_BUTTON_Y],
		"ab_time": [JOY_BUTTON_LEFT_STICK], "ab_magnet": [JOY_BUTTON_RIGHT_STICK],
		"pause": [JOY_BUTTON_START], "confirm": [JOY_BUTTON_A],
	}
	for action in keys:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for k in keys[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(action, ev)
	for action in pads:
		for b in pads[action]:
			var ev := InputEventJoypadButton.new()
			ev.button_index = b
			InputMap.action_add_event(action, ev)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_echo():
		return
	if event.is_action_pressed("fullscreen"):
		var fs := DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if fs else DisplayServer.WINDOW_MODE_FULLSCREEN)
		return
	if event.is_action_pressed("music"):
		audio.toggle_music()
		return

	match state:
		State.MENU:
			if event.is_action_pressed("confirm"):
				_start_game()
			elif event.is_action_pressed("controls"):
				hud.toggle_controls()
			elif event.is_action_pressed("ab_wall"):
				_select_char(-1)
			elif event.is_action_pressed("ab_grapple"):
				_select_char(1)
			elif event.is_action_pressed("left"):
				_select_track(-1)
			elif event.is_action_pressed("right"):
				_select_track(1)
		State.PAUSED:
			if event.is_action_pressed("pause"):
				_set_paused(false)
		State.DEAD:
			if dead_timer > 1.2:
				if event.is_action_pressed("ab_time"):
					_revive()
				elif event.is_action_pressed("confirm"):
					_start_game()
				elif event.is_action_pressed("pause"):
					_enter_menu()
		State.PLAYING:
			if event.is_action_pressed("pause"):
				_set_paused(true)
			elif event.is_action_pressed("left"):
				_on_dir(-1)
			elif event.is_action_pressed("right"):
				_on_dir(1)
			elif event.is_action_pressed("jump"):
				player.press_jump()
			elif event.is_action_released("jump"):
				player.release_jump()
			elif event.is_action_pressed("slide"):
				_on_slide()
			elif event.is_action_pressed("ab_dash"):
				if player.grounded and player.wall_side == 0 and not player.is_grappling():
					_use(DASH)
				else:
					_use(AIRDASH)
			elif event.is_action_pressed("ab_wall"):
				_use(WALL)
			elif event.is_action_pressed("ab_grapple"):
				_use(GRAPPLE)
			elif event.is_action_pressed("ab_time"):
				_use(TIMESHIFT)
			elif event.is_action_pressed("ab_phase"):
				_use(PHASE)
			elif event.is_action_pressed("ab_magnet"):
				_use(MAGNET)


func _on_dir(dir: int) -> void:
	if player.wall_side != 0:
		if dir == -player.wall_side:
			player.end_wall(false)
			audio.play("click", 0.8, -6.0)
		return
	# pushing into a wall from the outer lane starts a wall run
	if player.lane == dir and _wall_at(dir) and ab_cd[WALL] <= 0.0 and not player.is_grappling():
		_use(WALL, dir)
		return
	player.move(dir)
	audio.play("click", 0.9 if dir < 0 else 1.1, -8.0)


func _on_slide() -> void:
	if player.wall_side != 0:
		player.press_slide()
	elif player.is_grappling():
		player.release_grapple(false)
	elif not player.grounded:
		_use(SLAM)
	else:
		player.press_slide()


# ============================================================ flow
func _enter_menu() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	state = State.MENU
	world.speed = MENU_SPEED
	world.theme = start_zone
	world.reset(false)
	player.reset()
	cam.mode = CamScript.Mode.MENU
	audio.set_muffled(false)
	_clear_abilities()
	_snap_zone(start_zone)
	if player.char_idx != char_idx or (char_idx != 0 and player.rig == null):
		player.set_character(char_idx)
	player.set_props(true)
	hud.show_menu(best_score)
	_show_char()
	hud.set_track(ZONES[start_zone]["name"], start_zone, ZONES.size())


func _select_char(dir: int) -> void:
	if state != State.MENU:
		return
	char_idx = posmod(char_idx + dir, RigScript.count())
	player.reset()
	player.set_character(char_idx)
	player.set_props(true)
	_show_char()
	hud.flash(Color.WHITE, 0.2)
	audio.play("click", 1.2 + dir * 0.1)
	_save()


func _show_char() -> void:
	var d: Dictionary = RigScript.CHARACTERS[char_idx]
	hud.set_character(d["name"], d["hobby"], char_idx, RigScript.count())


func _select_track(dir: int) -> void:
	if state != State.MENU:
		return
	start_zone = posmod(start_zone + dir, ZONES.size())
	world.theme = start_zone
	world.reset(false)
	_snap_zone(start_zone)
	hud.set_track(ZONES[start_zone]["name"], start_zone, ZONES.size())
	hud.flash(Color.WHITE, 0.3)
	audio.play("click", 1.0 + dir * 0.1)


func _snap_zone(idx: int) -> void:
	zone_idx = idx
	zone_t = 1.0
	zone_cur = ZONES[idx].duplicate()
	_apply_zone(zone_cur)
	_set_weather(ZONES[idx]["fx"], ZONES[idx]["wet"])


func _start_game() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	slowmo_left = 0.0
	var from_menu := state == State.MENU
	speed = START_SPEED
	distance = 0.0
	score = 0.0
	gold = 0
	close_calls = 0
	grace = 0.0
	stumble_timer = 0.0
	portal_boost = 0.0
	coin_streak = 0
	last_km = 0
	flow = 0.0
	flow_tier = 0
	score_boost_t = 0.0
	new_best = false
	cores.clear()
	board_t = 0.0
	revive_cost = 100
	revive_bridge_t = 0.0
	world.speed = speed
	world.difficulty = 0.0
	warp_t = 0.0
	zone_start = 0.0
	world.theme = start_zone
	world.reset(true)
	player.reset()
	_clear_abilities()
	audio.set_muffled(false)
	cam.start_play()
	if not from_menu:
		cam.swoop = 0.0
	_snap_zone(start_zone)
	player.set_props(false)
	state = State.PLAYING
	hud.show_game()
	hud.zone_banner(ZONES[start_zone]["name"], "TRACK  %d" % (start_zone + 1))
	hud.popup("GO!", CYAN, 70)
	audio.play("portal", 1.2, -6.0)


func _set_paused(on: bool) -> void:
	if on and state == State.PLAYING:
		state = State.PAUSED
		get_tree().paused = true
		hud.show_pause(true)
		audio.play("click")
	elif not on and state == State.PAUSED:
		state = State.PLAYING
		get_tree().paused = false
		hud.show_pause(false)
		audio.play("click")


func _crash(title: String, from_fall := false) -> void:
	state = State.DEAD
	dead_timer = 0.0
	death_title = title
	player.die(from_fall)
	cam.mode = CamScript.Mode.DEAD
	cam.add_trauma(0.9 if not from_fall else 0.4)
	cam.kick(Vector3(0, 0.3, 1.5))
	audio.play("crash")
	audio.set_muffled(true)
	hud.flash(Color(1.0, 0.3, 0.5), 0.55)
	Engine.time_scale = 0.3
	slowmo_left = 0.8
	_clear_abilities()
	hud.set_markers([])
	hud.set_prompt("")
	var final := int(score)
	if final > best_score:
		best_score = final
		new_best = true
		_save()


func _show_game_over() -> void:
	hud.show_over({
		"title": death_title, "score": int(score), "distance": int(distance), "gold": gold,
		"close": close_calls, "best": best_score, "new_best": new_best,
		"revive": gold >= revive_cost, "revive_cost": revive_cost,
	})


# ============================================================ main loop
func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	if slowmo_left > 0.0:
		slowmo_left -= delta / maxf(Engine.time_scale, 0.01)
		if slowmo_left <= 0.0:
			Engine.time_scale = 1.0
	if state == State.PAUSED:
		return

	var ph: float = audio.beat_phase()
	beat = pow(1.0 - fposmod(ph, 1.0), 4.0)
	RenderingServer.global_shader_parameter_set("beat", beat)

	match state:
		State.MENU:
			# the fox jogs through the track preview; characters chill in their lobby
			var lobby: bool = char_idx != 0
			var ms := 0.0 if lobby else MENU_SPEED
			world.scroll(ms * delta)
			player.floor_y = 0.0
			player.tick(delta, ms, not lobby)
			fx.tick(delta, ms * delta)
		State.PLAYING:
			_play_step(delta)
		State.DEAD:
			dead_timer += delta
			player.tick(delta, 0.0, false)
			fx.tick(delta, 0.0)
			if dead_timer > 1.1 and not hud.is_over_visible():
				_show_game_over()

	_update_curve(delta)
	_update_zone(delta)
	world.update_fx(delta, beat)
	_spin_pickups(delta)
	player.curve = curve
	cam.update_cam(delta, player, _speed_factor(), _extra_fov(), curve, _cam_state())
	_update_visual_fx(delta)


func _play_step(delta: float) -> void:
	speed = minf(MAX_SPEED, speed + SPEED_GAIN * delta)
	_tick_abilities(delta)
	var wmult := _speed_mult()
	var eff := speed * wmult
	var dz := eff * delta
	distance += dz
	score += dz * 0.5 * _score_mult()
	world.speed = speed
	world.difficulty = clampf((speed - START_SPEED) / (MAX_SPEED - START_SPEED), 0.0, 1.0)
	world.scroll(dz)
	fx.tick(delta, dz)
	grace = maxf(0.0, grace - delta)
	stumble_timer = maxf(0.0, stumble_timer - delta)
	portal_boost = maxf(0.0, portal_boost - delta)
	score_boost_t = maxf(0.0, score_boost_t - delta)
	coin_streak_t -= delta
	if coin_streak_t <= 0.0:
		coin_streak = 0
	_tick_flow(delta)
	_tick_warp(delta)
	_update_traps(delta, dz / maxf(delta, 0.001))
	revive_bridge_t = maxf(0.0, revive_bridge_t - delta)
	if board_t > 0.0:
		board_t -= delta
		if board_t <= 0.0:
			player.set_board(false)
			hud.popup("BOARD WORN OUT", Color(1, 0.6, 0.8), 34)
	_move_drones(delta * (0.45 if ab_active[TIMESHIFT] > 0.0 else 1.0))

	# wall run bookkeeping
	if wall_active:
		if player.wall_side == 0:
			wall_active = false
			ab_cd[WALL] = ABILITIES[WALL]["cd"]
			grace = maxf(grace, 0.5)
		elif not _wall_at(player.wall_side, -2.0):
			player.end_wall(false)
		else:
			_add_flow(7.0 * delta)
			score += 40.0 * delta * _score_mult()

	_compute_floor(delta)
	player.tick(delta, eff, true)
	_update_grind(delta)
	if player.grounded:
		dashjump_carry = false
	if player.position.y < -4.0:
		_crash("FELL OFF THE SKYLINE", true)
		return
	_check_objects(delta)
	if state != State.PLAYING:
		return

	var km := int(distance / 1000.0)
	if km > last_km:
		last_km = km
		hud.popup("%d,000 M!" % km, CYAN, 56)
		audio.play("ready", 0.8)

	_update_hud_state()


func _update_hud_state() -> void:
	var grapple_target = _grapple_target()
	var any_wall := _wall_at(-1) or _wall_at(1)
	var air: bool = not player.grounded and player.wall_side == 0 and not player.is_grappling()
	var ab := []
	for i in ABILITIES.size():
		var a: Dictionary = ABILITIES[i]
		var cd: float = a["cd"]
		var dur: float = a["dur"]
		var free: bool = ab_cd[i] <= 0.0 and ab_active[i] <= 0.0
		var rdy := free
		var act := ab_active[i] / dur if dur > 0.0 else 0.0
		match i:
			DASH:
				rdy = free and player.grounded and player.wall_side == 0
			AIRDASH:
				rdy = free and air and player.air_dash_ready
			WALL:
				rdy = ab_cd[i] <= 0.0 and any_wall and player.wall_side == 0
				act = player.wall_t / 3.0 if player.wall_side != 0 else 0.0
			GRAPPLE:
				rdy = ab_cd[i] <= 0.0 and grapple_target != null and not player.is_grappling()
				act = 1.0 if player.is_grappling() else 0.0
			SLAM:
				rdy = free and air
		ab.append({"ready": rdy, "cd_ratio": ab_cd[i] / cd if cd > 0.0 else 0.0, "cd_left": ab_cd[i], "active_ratio": act})
	var sr := clampf((speed * _speed_mult() - START_SPEED) / (MAX_SPEED - START_SPEED), 0.0, 1.0)
	hud.update_hud(int(score), int(distance), _score_mult(), gold, int(speed * _speed_mult() * 9.0), sr, flow, flow_tier, cores, ab)

	# world-space markers + context prompts
	var markers := []
	if grapple_target != null and not player.is_grappling():
		var bp: Vector3 = player.bend(grapple_target.position)
		if not cam.is_position_behind(bp):
			markers.append({"pos": cam.unproject_position(bp), "color": GREEN, "text": "E  GRAPPLE", "big": true})
	if ab_cd[MAGNET] <= 0.0:
		var n := 0
		for obj in world.objects.get_children():
			if n >= 3:
				break
			if obj.get_meta("kind") == "core" and obj.position.z > -45.0 and obj.position.z < -4.0:
				var bp2: Vector3 = player.bend(obj.position)
				if not cam.is_position_behind(bp2):
					markers.append({"pos": cam.unproject_position(bp2), "color": PINK, "text": "C  PULL", "big": false})
					n += 1
	for obj in world.objects.get_children():
		if obj.get_meta("kind") == "tunnel" and not obj.get_meta("hit") and obj.position.z > -90.0 and obj.position.z < -4.0:
			var tp: Vector3 = player.bend(obj.position + Vector3(0, 1.5, 0))
			if not cam.is_position_behind(tp):
				var tg: int = obj.get_meta("target")
				markers.append({"pos": cam.unproject_position(tp), "color": ThemesScript.ACCENT[tg], "text": "WARP TO  " + ZONES[tg]["name"], "big": true})
	hud.set_markers(markers)
	var prompt := ""
	if player.wall_side != 0:
		prompt = "SPACE  wall-jump      A / D  drop off"
	elif any_wall and ab_cd[WALL] <= 0.0 and not player.is_grappling():
		prompt = "Q  or push into the wall  -  WALL RUN"
	elif player.is_grappling():
		prompt = "SPACE  release with boost"
	elif player.boarding:
		prompt = "SKATEBOARD  %ds   ·   jump onto rails to grind" % int(board_t)
	hud.set_prompt(prompt)


func _compute_floor(delta: float) -> void:
	var f := 0.0
	var px: float = player.position.x
	var py: float = player.position.y
	for h in world.holes:
		if not is_instance_valid(h):
			continue
		var near: float = h.position.z
		var far: float = near - float(h.get_meta("len", 8.0))
		if near - 0.25 > 0.0 and far + 0.25 < 0.0:
			f = -1000.0
	if f < -100.0 and revive_bridge_t > 0.0 and py > -0.3:
		f = 0.0
	on_rail = false
	for obj in world.objects.get_children():
		var kind: String = obj.get_meta("kind")
		if not kind in WorldScript.SOLID:
			continue
		var box: AABB = obj.get_meta("box")
		var o: Vector3 = obj.position
		if px > o.x + box.position.x - 0.35 and px < o.x + box.end.x + 0.35 \
				and 0.0 > o.z + box.position.z - 0.35 and 0.0 < o.z + box.end.z + 0.35:
			var top := o.y + box.end.y
			if py >= top - 0.45 and top >= f:
				f = top
				on_rail = kind == "rail"
	player.floor_y = f


func _move_drones(wdelta: float) -> void:
	for obj in world.objects.get_children():
		if obj.get_meta("kind") != "drone" or obj.position.z < -90.0:
			continue
		var t: float = obj.get_meta("t") + wdelta
		obj.set_meta("t", t)
		obj.position.x = float(obj.get_meta("cx", obj.position.x)) + sin(float(obj.get_meta("ph")) + t * 1.7) * float(obj.get_meta("amp", 0.0))


func _check_objects(delta: float) -> void:
	var pbox: AABB = player.get_hitbox()
	var pc: Vector3 = player.position + Vector3(0, 0.9, 0)
	var pulling := ab_active[MAGNET] > 0.0
	for obj in world.objects.get_children():
		if obj.is_queued_for_deletion():
			continue
		var kind: String = obj.get_meta("kind")
		if kind == "coin" or kind == "core":
			if pulling and obj.position.z > -50.0 and obj.position.z < 4.0:
				obj.position = obj.position.move_toward(pc, (70.0 + speed) * delta)
			if obj.position.distance_to(pc) < (1.3 if kind == "coin" else 1.5):
				if kind == "coin":
					_collect_coin(obj)
				else:
					_gain_core(obj)
		elif kind == "portal":
			if not obj.get_meta("hit") and obj.position.z > 0.0:
				obj.set_meta("hit", true)
				_portal()
		elif kind == "tunnel":
			if not obj.get_meta("hit") and obj.position.z > -0.5:
				obj.set_meta("hit", true)
				if absf(obj.position.x - player.position.x) < 1.4 and player.position.y < 3.0:
					_warp(obj.get_meta("target"))
		elif kind == "board":
			if obj.position.distance_to(pc) < 1.7:
				_gain_board(obj)
		elif kind == "kicker":
			if not obj.get_meta("hit") and obj.position.z > -1.2 and absf(obj.position.x - player.position.x) < 1.2 \
					and player.position.y < 0.6:
				obj.set_meta("hit", true)
				_kicker()
		elif kind == "pad":
			if not obj.get_meta("hit") and obj.position.z > -1.0 and absf(obj.position.x - player.position.x) < 1.3 \
					and player.position.y < 0.6:
				obj.set_meta("hit", true)
				_boost_pad()
		elif kind in ["jump", "slide", "car", "speaker", "crate", "drone", "rail", "pop_wall", "pop_spikes", "drop"]:
			var box: AABB = obj.get_meta("box")
			var wb := AABB(box.position + obj.position, box.size)
			if not obj.get_meta("passed", false) and wb.position.z > 0.6:
				obj.set_meta("passed", true)
				if obj.get_meta("phased", false):
					_phased_through()
				else:
					_check_close_call(obj)
			if wb.intersects(pbox):
				var on_top: bool = kind in WorldScript.SOLID and player.position.y >= wb.end.y - 0.45
				if not on_top:
					_on_hit(obj, kind)
					if state != State.PLAYING:
						return


func _collect_coin(obj: Node3D) -> void:
	gold += 1
	coin_streak += 1
	coin_streak_t = 0.6
	score += 10.0 * _score_mult()
	_add_flow(1.2)
	fx.sparkle(obj.position, GOLD)
	audio.play("coin", 1.0 + minf(coin_streak, 12) * 0.025, -3.0)
	hud.gold_pop()
	obj.queue_free()


func _gain_core(obj: Node3D) -> void:
	var t: String = obj.get_meta("ctype")
	fx.burst(obj.position, {"shield": CYAN, "surge": PINK, "gold": GOLD}[t], 14, 8.0, 0.2, 0.5, 0.0)
	audio.play("orb")
	obj.queue_free()
	_add_flow(8.0)
	cam.punch_fov(4.0)
	match t:
		"gold":
			gold += 20
			score_boost_t = 8.0
			hud.popup("GOLD CORE  +20  ·  x2 SCORE", GOLD, 38)
			hud.gold_pop()
		"shield":
			_store_core(t)
			hud.popup("SHIELD CORE  -  blocks one crash", CYAN, 36)
		"surge":
			_store_core(t)
			hud.popup("SURGE CORE  -  skips one cooldown", PINK, 36)


func _store_core(t: String) -> void:
	if cores.size() >= 3:
		cores.pop_front()
	cores.append(t)
	player.set_cores(cores)


func _consume_core(t: String) -> void:
	cores.erase(t)
	player.set_cores(cores)


func _check_close_call(obj: Node3D) -> void:
	if player.lane_change_time < 0.5 and player.prev_lane != player.lane \
			and absf(obj.position.x - player.prev_lane * LANE_WIDTH) < 0.3:
		close_calls += 1
		var pts := 50 * _score_mult()
		score += pts
		_add_flow(12.0)
		hud.popup("CLOSE CALL!  +%d" % pts, CYAN, 42)
		audio.play("close")
		cam.punch_fov(5.0)
		_slowmo(0.45, 0.16)


func _phased_through() -> void:
	var pts := 100 * _score_mult()
	score += pts
	_add_flow(18.0)
	hud.popup("PHASED THROUGH!  +%d" % pts, CYAN, 42)
	audio.play("close", 1.3)
	cam.punch_fov(6.0)


func _portal() -> void:
	var pts := 250 * _score_mult()
	score += pts
	_add_flow(20.0)
	portal_boost = 1.6
	cam.punch_fov(14.0)
	cam.kick(Vector3(0, 0, 1.4))
	cam.add_trauma(0.2)
	hud.flash(CYAN, 0.35)
	hud.popup("PORTAL BOOST  +%d" % pts, CYAN, 48)
	audio.play("portal")
	fx.ring(Vector3(0, 2.2, -1.0), CYAN, 7.0, 0.6)


func _boost_pad() -> void:
	portal_boost = 1.2
	_add_flow(10.0)
	cam.punch_fov(10.0)
	cam.kick(Vector3(0, 0, 1.0))
	audio.play("portal", 1.5, -4.0)
	hud.popup("BOOST!", CYAN, 40)
	fx.burst(player.position, CYAN, 10, 6.0, 0.15, 0.4, 0.0)


func _on_hit(obj: Node3D, kind: String) -> void:
	if grace > 0.0 or player.is_grappling() or player.wall_side != 0:
		return
	if player.phase_t > 0.0:
		obj.set_meta("phased", true)
		return
	var breaking: bool = kind in WorldScript.WEAK and (player.dash_t > 0.0 or player.air_dash_t > 0.0 or player.slamming)
	if breaking:
		world.smash(obj, fx)
		_hitstop(0.05)
		cam.add_trauma(0.3)
		cam.kick(Vector3(0, 0, -0.5))
		audio.play("smash", randf_range(0.9, 1.1))
		var pts := 30 * _score_mult()
		score += pts
		_add_flow(8.0)
		hud.popup("SMASH!  +%d" % pts, PINK, 40)
		return
	if cores.has("shield"):
		_consume_core("shield")
		world.smash(obj, fx)
		grace = 1.0
		_hitstop(0.08)
		cam.add_trauma(0.55)
		hud.flash(CYAN, 0.35)
		hud.popup("SHIELD CORE SAVED YOU", CYAN, 42)
		audio.play("shield_break")
		return
	if player.boarding:
		player.set_board(false)
		board_t = 0.0
		world.smash(obj, fx)
		grace = 1.2
		_hitstop(0.08)
		cam.add_trauma(0.5)
		hud.flash(Color(1, 0.5, 0.8), 0.3)
		hud.popup("BOARD BROKEN  -  YOU'RE OK!", Color(1, 0.6, 0.85), 40)
		audio.play("shield_break", 0.8)
		return
	var side: bool = absf(player.position.x - obj.position.x) > 0.8 and player.prev_lane != player.lane \
			and player.lane_change_time < 0.6 and player.wall_side == 0
	if side and stumble_timer <= 0.0:
		player.bounce_back()
		stumble_timer = 5.0
		grace = 0.5
		cam.add_trauma(0.45)
		cam.kick_roll(0.2)
		hud.flash(Color(1.0, 0.2, 0.3), 0.25)
		hud.popup("STUMBLE!  CAREFUL", Color(1.0, 0.45, 0.45), 42)
		audio.play("stumble")
		flow *= 0.5
		return
	last_hit = "%s x=%.1f z=%.1f y=%.1f | player lane %d x=%.1f y=%.1f lct=%.2f safe=%d" % [kind, obj.position.x, obj.position.z, obj.position.y, player.lane, player.position.x, player.position.y, player.lane_change_time, world.safe_lane]
	_crash("WIPED OUT")


# ============================================================ abilities
func _use(i: int, arg := 0) -> void:
	if state != State.PLAYING:
		return
	var a: Dictionary = ABILITIES[i]
	var id: String = a["id"]
	var side := 0
	var target = null
	match id:
		"dash":
			if not player.grounded:
				return
		"airdash":
			if player.grounded or player.wall_side != 0 or player.is_grappling() or not player.air_dash_ready:
				_deny(i, "")
				return
		"wallrun":
			if player.wall_side != 0 or player.is_grappling():
				return
			if arg != 0:
				side = arg
			elif player.lane != 0 and _wall_at(player.lane):
				side = player.lane
			elif _wall_at(-1):
				side = -1
			elif _wall_at(1):
				side = 1
			if side == 0:
				_deny(i, "NO WALL NEARBY")
				return
		"grapple":
			if player.is_grappling():
				return
			target = _grapple_target()
			if target == null:
				_deny(i, "NO GRAPPLE POINT IN RANGE")
				return
		"slam":
			if player.grounded or player.wall_side != 0 or player.is_grappling():
				return
	if ab_cd[i] > 0.0 or ab_active[i] > 0.0:
		if id == "slam":
			player.slam(false)
			return
		if cores.has("surge") and id != "airdash":
			_consume_core("surge")
			ab_cd[i] = 0.0
			ab_active[i] = 0.0
			hud.popup("SURGE!  COOLDOWN SKIPPED", PINK, 36)
		else:
			_deny(i, "")
			return
	hud.slot_used(i)
	var p: Vector3 = player.position
	match id:
		"dash":
			ab_active[i] = a["dur"]
			player.dash_t = a["dur"]
			cam.kick(Vector3(0, 0, 1.3))
			cam.punch_fov(12.0)
			cam.add_trauma(0.15)
			fx.ring(p + Vector3(0, 1.0, 0.5), PINK, 3.0, 0.35, 20.0)
			audio.play("dash")
			_add_flow(4.0)
		"airdash":
			var dir := int(Input.is_action_pressed("right")) - int(Input.is_action_pressed("left"))
			player.air_dash(dir)
			ab_active[i] = a["dur"]
			if dir == 0:
				cam.punch_fov(11.0)
				cam.kick(Vector3(0, 0.15, 1.2))
			else:
				cam.punch_fov(5.0)
				cam.kick(Vector3(dir * 0.7, 0.1, 0.2))
				cam.kick_roll(-dir * 0.4)
			fx.ring(p + Vector3(0, 1.0, 0.0), Color(1, 0.6, 0.9), 2.5, 0.3, 10.0)
			fx.burst(p + Vector3(0, 1.0, 0), PINK, 8, 5.0, 0.12, 0.3, 0.0)
			audio.play("airdash")
			_add_flow(6.0)
		"wallrun":
			player.start_wall(side)
			wall_active = true
			cam.kick(Vector3(-side * 0.6, 0.2, 0))
			cam.punch_fov(6.0)
			audio.play("wall")
			hud.popup("WALL RUN!", a["color"], 42)
			_add_flow(10.0)
		"grapple":
			player.start_grapple(target)
			target.set_meta("used", true)
			grapple_active = true
			cam.punch_fov(8.0)
			cam.kick(Vector3(0, 0.4, 0.4))
			fx.burst(target.position, GREEN, 12, 6.0, 0.15, 0.4, 0.0)
			audio.play("grapple")
			hud.popup("GRAPPLE!", GREEN, 42)
			_add_flow(12.0)
		"timeshift":
			ab_active[i] = a["dur"]
			audio.play("warp")
			audio.set_warp(true)
			hud.flash(Color(0.6, 0.6, 1.0), 0.3)
			cam.punch_fov(-10.0)
			hud.popup("TIME SHIFT", a["color"], 44)
		"phase":
			ab_active[i] = a["dur"]
			player.phase_t = a["dur"]
			player.set_phase_visual(true)
			audio.play("phase")
			hud.flash(CYAN, 0.2)
			cam.punch_fov(6.0)
			cam.kick(Vector3(0, 0, 0.6))
			hud.popup("PHASE", CYAN, 44)
		"magnet":
			ab_active[i] = a["dur"]
			audio.play("magnet")
			fx.ring(p + Vector3(0, 1.0, 0), Color(1, 0.45, 0.45), 9.0, 0.5)
			fx.ring(p + Vector3(0, 1.0, 0), Color(1, 0.45, 0.45), 5.0, 0.35)
			cam.punch_fov(-4.0)
			hud.popup("MAGNET PULL", a["color"], 42)
		"slam":
			player.slam(true)
			ab_cd[i] = a["cd"]
			audio.play("dash", 0.55)
			cam.punch_fov(-6.0)
			cam.kick(Vector3(0, 0.7, 0))


func _deny(i: int, msg: String) -> void:
	hud.slot_deny(i)
	audio.play("deny")
	if msg != "":
		hud.popup(msg, Color(0.8, 0.75, 0.9), 30)


func _tick_abilities(delta: float) -> void:
	for i in ABILITIES.size():
		if ab_active[i] > 0.0:
			ab_active[i] -= delta
			if ab_active[i] <= 0.0:
				ab_active[i] = 0.0
				_end_ability(i)
				ab_cd[i] = ABILITIES[i]["cd"]
		elif ab_cd[i] > 0.0:
			if (i == WALL and wall_active) or (i == GRAPPLE and grapple_active):
				continue
			ab_cd[i] = maxf(0.0, ab_cd[i] - delta)
			if ab_cd[i] <= 0.0 and i != AIRDASH:
				audio.play("ready", 1.0, -10.0)


func _end_ability(i: int) -> void:
	match i:
		DASH:
			grace = maxf(grace, 0.1)
		TIMESHIFT:
			audio.set_warp(false)
		PHASE:
			player.set_phase_visual(false)
			grace = maxf(grace, 0.15)


func _clear_abilities() -> void:
	for i in ab_cd.size():
		ab_cd[i] = 0.0
		ab_active[i] = 0.0
	wall_active = false
	grapple_active = false
	dashjump_carry = false
	audio.set_warp(false)
	player.set_phase_visual(false)
	player.set_aura(false)


func _wall_at(side: int, margin := -3.0) -> bool:
	for obj in world.objects.get_children():
		if obj.get_meta("kind") != "wall" or int(obj.get_meta("side")) != side:
			continue
		var half: float = obj.get_meta("half")
		if obj.position.z + half > 1.0 and obj.position.z - half < margin:
			return true
	return false


func _grapple_target():
	var best = null
	var best_z := -999.0
	for obj in world.objects.get_children():
		if obj.get_meta("kind") != "anchor" or obj.get_meta("used"):
			continue
		var z: float = obj.position.z
		if z > -44.0 and z < -3.0 and z > best_z:
			best = obj
			best_z = z
	return best


func _on_grapple_released() -> void:
	grapple_active = false
	grace = maxf(grace, 0.45)
	ab_cd[GRAPPLE] = ABILITIES[GRAPPLE]["cd"]
	cam.punch_fov(10.0)
	cam.kick(Vector3(0, -0.4, 0.9))
	fx.ring(player.position + Vector3(0, 1.0, 0), GREEN, 3.0, 0.35)
	audio.play("djump", 1.2)
	_add_flow(8.0)


func _slam_impact() -> void:
	var n := 0
	var p: Vector3 = player.position
	for obj in world.objects.get_children():
		if obj.is_queued_for_deletion():
			continue
		if obj.get_meta("kind") in WorldScript.WEAK and obj.position.z > -10.0 and obj.position.z < 3.0 \
				and absf(obj.position.x - p.x) < 4.0 and absf(obj.position.y - p.y) < 3.0:
			world.smash(obj, fx)
			n += 1
	player.launch(15.0 + mini(n, 3) * 1.5)
	cam.add_trauma(0.75)
	cam.kick(Vector3(0, -1.1, 0))
	cam.punch_fov(12.0)
	_hitstop(0.09)
	fx.ring(p + Vector3(0, 0.2, 0), GOLD, 7.0, 0.5, 0.0, true)
	fx.ring(p + Vector3(0, 0.2, 0), Color.WHITE, 4.0, 0.35, 0.0, true)
	fx.burst(p + Vector3(0, 0.3, 0), GOLD, 16, 9.0, 0.18, 0.5)
	hud.flash(GOLD, 0.3)
	audio.play("shock")
	if n > 0:
		var pts := n * 40 * _score_mult()
		score += pts
		_add_flow(10.0 * n)
		hud.popup("SLAM x%d  +%d" % [n, pts], GOLD, 44)
	else:
		_add_flow(4.0)


# ============================================================ skate park + traps
func _gain_board(obj: Node3D) -> void:
	obj.queue_free()
	board_t = 30.0
	player.set_board(true)
	fx.burst(player.position + Vector3(0, 0.5, 0), PINK, 16, 7.0, 0.16, 0.5, 0.0)
	hud.popup("SKATEBOARD!  grind rails, hit ramps", Color(1, 0.55, 0.85), 40)
	audio.play("orb", 0.8)
	cam.punch_fov(8.0)
	_add_flow(10.0)


func _kicker() -> void:
	var big: bool = player.boarding
	player.launch(23.0 if big else 19.0)
	cam.kick(Vector3(0, 0.6, 0.8))
	cam.punch_fov(10.0)
	audio.play("djump", 0.9)
	var pts := (150 if big else 60) * _score_mult()
	score += pts
	_add_flow(14.0 if big else 8.0)
	hud.popup(("KICKFLIP!  +%d" if big else "AIR!  +%d") % pts, Color(1, 0.8, 0.3), 42)
	fx.burst(player.position, Color(1, 0.8, 0.3), 12, 6.0, 0.15, 0.4, 0.0)


func _update_grind(delta: float) -> void:
	var grinding_now: bool = on_rail and player.grounded
	if grinding_now and not player.grinding:
		grind_t = 0.0
		hud.popup("GRIND!" if player.boarding else "RAIL RUN!", CYAN, 40)
		cam.kick(Vector3(0, -0.2, 0))
	player.grinding = grinding_now and player.boarding
	if not grinding_now:
		return
	grind_t += delta
	score += (90.0 if player.boarding else 30.0) * delta * _score_mult()
	_add_flow((12.0 if player.boarding else 5.0) * delta)
	grind_fx_t -= delta
	if grind_fx_t <= 0.0:
		grind_fx_t = 0.05
		fx.burst(player.position + Vector3(0, 0.1, 0.2), Color(1.0, 0.8, 0.3), 3, 6.0, 0.07, 0.25, 12.0)
		if int(grind_t * 20.0) % 5 == 0:
			audio.play("slide", 1.7, -8.0)


func _update_traps(delta: float, world_speed: float) -> void:
	var trigger_z := -maxf(24.0, world_speed * 1.1)
	for obj in world.objects.get_children():
		var kind: String = obj.get_meta("kind")
		if kind != "pop_wall" and kind != "pop_spikes" and kind != "drop":
			continue
		if not obj.get_meta("trig"):
			if obj.position.z > trigger_z:
				obj.set_meta("trig", true)
				audio.play("grapple", 0.55 if kind == "drop" else 0.8, -2.0)
			continue
		if obj.position.y != 0.0:
			var rate := 34.0 if kind == "drop" else 16.0
			obj.position.y = move_toward(obj.position.y, 0.0, rate * delta)
			if obj.position.y == 0.0:
				fx.burst(obj.position + Vector3(0, 0.2, 0), Color(0.9, 0.85, 0.8), 8, 5.0, 0.15, 0.4)
				if obj.position.z > -15.0:
					cam.add_trauma(0.15)


func _revive() -> void:
	if state != State.DEAD or gold < revive_cost:
		return
	gold -= revive_cost
	revive_cost *= 2
	for obj in world.objects.get_children():
		var kind: String = obj.get_meta("kind")
		if kind in ["jump", "slide", "car", "speaker", "crate", "drone", "rail", "pop_wall", "pop_spikes", "drop"] \
				and obj.position.z > -45.0:
			world.smash(obj, fx)
	Engine.time_scale = 1.0
	slowmo_left = 0.0
	player.revive()
	revive_bridge_t = 2.5
	grace = 2.5
	state = State.PLAYING
	cam.mode = CamScript.Mode.PLAY
	audio.set_muffled(false)
	hud.show_game()
	hud.flash(Color(1, 0.85, 0.4), 0.6)
	hud.popup("REVIVED!", GOLD, 60)
	audio.play("overdrive")


# ============================================================ flow meter
func _add_flow(v: float) -> void:
	flow = minf(100.0, flow + v)
	flow_idle = 0.0


func _tick_flow(delta: float) -> void:
	flow_idle += delta
	if flow_idle > 1.8:
		flow = maxf(0.0, flow - 9.0 * delta)
	var tier := 0
	if flow >= 70.0:
		tier = 2
	elif flow >= 35.0:
		tier = 1
	if tier > flow_tier:
		hud.popup("FLOW  x%d  BONUS!" % (tier + 1), Color(1.0, 0.55, 0.95), 46)
		audio.play("ready", 1.4)
		cam.punch_fov(6.0)
	flow_tier = tier


func _speed_mult() -> float:
	var m := 1.0
	if ab_active[DASH] > 0.0:
		m *= 1.9
	if player.air_dash_t > 0.0 and player.air_dash_dir == 0:
		m *= 1.6
	if dashjump_carry:
		m *= 1.3
	if ab_active[TIMESHIFT] > 0.0:
		m *= 0.45
	if portal_boost > 0.0:
		m *= 1.25
	if warp_t > 0.0:
		m *= 1.8
	if player.boarding:
		m *= 1.15
	return m


func _score_mult() -> int:
	var m := 1 + mini(5, int(distance / 600.0)) + flow_tier
	if score_boost_t > 0.0:
		m *= 2
	return m


func _speed_factor() -> float:
	if state != State.PLAYING:
		return 0.0
	return clampf((speed * _speed_mult() - START_SPEED) / (MAX_SPEED - START_SPEED), 0.0, 1.4)


func _extra_fov() -> float:
	var f := 0.0
	if state == State.PLAYING:
		if ab_active[DASH] > 0.0:
			f += 14.0
		if ab_active[TIMESHIFT] > 0.0:
			f -= 7.0
		if portal_boost > 0.0:
			f += 6.0
		if warp_t > 0.0:
			f += 22.0 * warp_t
		if player.wall_side != 0:
			f += 7.0
		if player.is_grappling():
			f += 10.0
		f += flow * 0.06
	return f


func _cam_state() -> Dictionary:
	var gp = null
	if player.is_grappling():
		gp = player.bend(player.anchor.position)
	return {
		"wall": player.wall_side,
		"grapple": gp,
		"slam": player.slamming and player.vy < 0.0,
		"shift": ab_active[TIMESHIFT] > 0.0,
		"phase": player.phase_t > 0.0,
		"flow": flow / 100.0,
		"air": not player.grounded,
	}


func _hitstop(d: float) -> void:
	if Engine.time_scale >= 0.99:
		Engine.time_scale = 0.05
		slowmo_left = d


func _slowmo(scale: float, d: float) -> void:
	if Engine.time_scale >= 0.99:
		Engine.time_scale = scale
		slowmo_left = d


# ============================================================ visuals
func _update_curve(delta: float) -> void:
	curve_timer -= delta
	if curve_timer <= 0.0:
		curve_timer = randf_range(6.0, 11.0)
		curve_target = Vector2(randf_range(-0.0017, 0.0017), randf_range(-0.001, 0.0004))
	curve = curve.lerp(curve_target, 1.0 - exp(-0.35 * delta))
	RenderingServer.global_shader_parameter_set("curve_amount", curve)


func _next_zone() -> int:
	return (zone_idx + 1) % ZONES.size()


func _update_zone(delta: float) -> void:
	if state == State.PLAYING:
		# the world spawns scenery ~215 m ahead, so switch its theme early
		world.theme = _next_zone() if distance + ZONE_LOOKAHEAD >= zone_start + ZONE_LEN else zone_idx
		if distance >= zone_start + ZONE_LEN:
			zone_start += ZONE_LEN
			_begin_zone(_next_zone(), true)
	if zone_t < 1.0:
		zone_t = minf(1.0, zone_t + delta / 3.0)
		var e := zone_t * zone_t * (3.0 - 2.0 * zone_t)
		var to: Dictionary = ZONES[zone_idx]
		for k in to:
			if to[k] is Color:
				zone_cur[k] = (zone_from[k] as Color).lerp(to[k], e)
			elif to[k] is float:
				zone_cur[k] = lerpf(zone_from[k], to[k], e)
		_apply_zone(zone_cur)


func _begin_zone(idx: int, announce: bool) -> void:
	zone_from = zone_cur.duplicate()
	zone_idx = idx
	zone_t = 0.0
	_set_weather(ZONES[idx]["fx"], ZONES[idx]["wet"])
	if announce:
		hud.zone_banner(ZONES[idx]["name"], "TRACK  %d" % (idx + 1))
		audio.play("portal", 0.7)
		hud.flash(Color.WHITE, 0.25)
		cam.punch_fov(10.0)


func _warp(target: int) -> void:
	warp_t = 1.0
	warp_target = target
	warped = false
	grace = 2.5
	cam.punch_fov(28.0)
	cam.kick(Vector3(0, 0, 2.0))
	cam.add_trauma(0.35)
	audio.play("portal", 0.6)
	audio.play("dash", 0.5)
	_add_flow(25.0)


func _tick_warp(delta: float) -> void:
	if warp_t <= 0.0:
		return
	warp_t -= delta
	if not warped and warp_t < 0.62:
		warped = true
		hud.flash(Color.WHITE, 1.2)
		world.theme = warp_target
		world.reset(true)
		zone_start = distance
		_snap_zone(warp_target)
		hud.zone_banner(ZONES[warp_target]["name"], "WARPED  ·  TRACK  %d" % (warp_target + 1))
		var pts := 300 * _score_mult()
		score += pts
		hud.popup("WARP!  +%d" % pts, ThemesScript.ACCENT[warp_target], 50)
		cam.punch_fov(-10.0)
		audio.play("portal", 1.3)


func _apply_zone(z: Dictionary) -> void:
	sky_mat.sky_top_color = z["top"]
	sky_mat.sky_horizon_color = z["hor"]
	sky_mat.ground_horizon_color = z["hor"]
	sky_mat.ground_bottom_color = z["ground"]
	env.fog_light_color = z["fog"]
	env.ambient_light_energy = z["amb"]
	sun.light_color = z["sun"]
	sun.light_energy = z["sun_e"]
	stars_mat.albedo_color.a = z["stars"]
	env.glow_intensity = 0.9 + float(z["stars"]) * 0.5 + float(z["plight"]) * 0.3
	env.fog_density = z["fog_d"]
	if player_light:
		player_light.light_energy = z["plight"]


func _spin_pickups(delta: float) -> void:
	var t := Time.get_ticks_msec() * 0.004
	for obj in world.objects.get_children():
		var kind: String = obj.get_meta("kind")
		if kind == "coin":
			obj.rotate_y(4.0 * delta)
		elif kind == "anchor":
			var in_range: bool = state == State.PLAYING and not obj.get_meta("used") and obj.position.z > -44.0 and obj.position.z < -3.0
			var s := 1.0 + (0.25 + sin(t * 3.0) * 0.15 if in_range else 0.0)
			obj.scale = obj.scale.lerp(Vector3(s, s, s), 0.2)


func _update_visual_fx(delta: float) -> void:
	var sf := _speed_factor()
	var playing := state == State.PLAYING
	var dashing: bool = playing and (ab_active[DASH] > 0.0 or player.air_dash_t > 0.0)
	speed_lines.emitting = playing and (warp_t > 0.0 or sf > 0.3 or dashing or portal_boost > 0.0 or flow > 35.0 or player.is_grappling())
	var ab := 0.0015 + sf * 0.004 + flow * 0.00005
	var blur := 0.0
	if playing:
		if dashing:
			ab += 0.012
			blur += 0.05
		if portal_boost > 0.0:
			blur += 0.035
		if player.is_grappling():
			blur += 0.03
		if warp_t > 0.0:
			blur += 0.12 * warp_t
			ab += 0.02 * warp_t
		blur += maxf(0.0, sf - 0.5) * 0.04
	var shift_t := 0.55 if (playing and ab_active[TIMESHIFT] > 0.0) else 0.0
	shift_amount = lerpf(shift_amount, shift_t, 1.0 - exp(-6.0 * delta))
	var ph_t := 1.0 if (playing and player.phase_t > 0.0) else 0.0
	phase_amount = lerpf(phase_amount, ph_t, 1.0 - exp(-10.0 * delta))
	ab += phase_amount * 0.02
	var tint := Color(0.6, 0.8, 1.0).lerp(Color(0.4, 1.0, 1.0), phase_amount)
	hud.set_post(ab, maxf(shift_amount, phase_amount * 0.35), blur, tint)


# ============================================================ player callbacks
func _on_jumped(kind: String) -> void:
	match kind:
		"double":
			audio.play("djump")
			fx.burst(player.position + Vector3(0, 0.2, 0), CYAN, 8, 5.0, 0.14, 0.35, 0.0)
			cam.kick(Vector3(0, 0.25, 0))
			_add_flow(2.0)
		"dash_jump":
			dashjump_carry = true
			audio.play("djump", 0.8)
			cam.punch_fov(8.0)
			cam.kick(Vector3(0, 0.4, 0.8))
			hud.popup("DASH JUMP!", PINK, 38)
			fx.burst(player.position, PINK, 12, 6.0, 0.15, 0.35, 0.0)
			_add_flow(10.0)
		"wall_jump":
			audio.play("djump", 1.1)
			cam.kick(Vector3(player.x_vel * 0.03, 0.3, 0))
			cam.kick_roll(0.25 * signf(player.x_vel))
			_add_flow(8.0)
		_:
			audio.play("jump", randf_range(0.95, 1.05), -2.0)


func _on_landed(impact: float, was_slam: bool) -> void:
	if state != State.PLAYING and state != State.MENU:
		return
	if was_slam and state == State.PLAYING:
		_slam_impact()
		return
	audio.play("land", 1.0, -6.0 + clampf(impact * 0.2, 0.0, 6.0))
	cam.kick(Vector3(0, -clampf(impact * 0.018, 0.05, 0.6), 0))
	if impact > 25.0:
		cam.add_trauma(0.3)
		fx.burst(player.position, PINK, 10, 6.0, 0.16, 0.35, 10.0)
	elif impact > 12.0:
		cam.add_trauma(0.08)


# ============================================================ save
func _load() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		best_score = int(cfg.get_value("game", "best", 0))
		char_idx = int(cfg.get_value("game", "char", 1))


func _save() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("game", "best", best_score)
	cfg.set_value("game", "char", char_idx)
	cfg.save(SAVE_PATH)
