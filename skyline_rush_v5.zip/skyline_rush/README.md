# SKYLINE RUSH v5: endless runner with 8 tracks + 6 runners (Godot 4.3+, PC)

Open Godot 4.3 or newer → Import → choose `project.godot` → press F5.
There are no asset files: the art is built from shapes and code, and the music and sounds are generated when the game starts.

## Moves and abilities
| Key | Ability | What it does |
|---|---|---|
| Shift (ground) | **Dash** | A quick burst forward that smashes weak obstacles (crates, amps, drones). Jump during a dash for a higher, faster **dash-jump**. |
| Shift (in air) | **Air Dash** | A forward burst, or a sideways barrel roll if you hold A/D. You get one per jump, and it recharges when you land, wall-run or grapple. |
| Q, or push into a wall | **Wall Run** | Run along the neon glass walls for up to 3 s, skipping every lane obstacle. Space kicks you off the wall; A/D drops you off. |
| E | **Grapple** | Hook the green anchors (an on-screen marker shows when one is in range) to swing over wide gaps or reel up onto the glass sky-highways. Space lets go with a boost. |
| R | **Time Shift** | Slows the world (including patrolling drones) for 3 s while you keep full speed. |
| F | **Phase** | Become intangible for 1 s. Time it to ghost through one obstacle, even a car or speaker stack. |
| C | **Magnet Pull** | Yanks power cores and gold to you, even ones high up or in other lanes. |
| S (in air) | **Ground Slam** | Slam down, destroy weak obstacles around you, and bounce back up. |

**Power cores**, which you usually reach with Magnet Pull, grapples or double jumps:
- cyan **Shield**: blocks one crash
- pink **Surge**: lets you use one ability that is still on cooldown
- gold: +20 gold and double score for 8 s

You can hold up to 3 cores, and they orbit the fox.

**Flow meter:** tricks fill it. That includes close calls, smashes, wall runs, grapples, phasing through obstacles and dash-jumps. At 35% you get +1 to your score multiplier, and at 70% you get +2.

## The map
- **Sky roads:** a neon road that curves and dips into the distance, with gaps you jump over or grapple across.
- **Wall-run sections:** glass walls with gold you can only reach by running on the wall.
- **Sky-highways:** glass roads high above the main road, full of gold and reached by grappling.
- **Obstacles:** drones that sweep across the lanes, breakable crates, cars you can run on top of, speaker stacks, laser gates, boost pads and portals.
- **Zones:** the sky changes every 900 m. Pink Dawn → Neon Dusk → Midnight Aurora (stars, stronger neon glow) → Crystal Skies.
- **Scenery:** giant spinning vinyl records, floating islands, searchlight beams, speaker towers and a giant speaker arch, all pulsing to the music.

## Camera and game feel
- **Spring kicks:** jumps, landings, dashes, slams and hits nudge the camera, and it springs back with a slight bounce.
- **Hit-stop:** the game freezes for a split second when you smash something, and slows briefly on close calls.
- **Context framing:** the camera tilts during a wall run, pulls back to show a grapple, looks down during a slam, and moves in closer during Time Shift.
- **Field of view** widens with speed, flow and dashes, and the camera leans into the road's curves.
- **Screen effects:** a radial speed blur, colour fringing at the edges of the screen, a colour tint for Time Shift and Phase, and speed lines.

## Other controls
A/D change lane, W/Space jump (hold for higher, press again in the air for a double jump), S/Ctrl slide, Esc pause, M music, F11 fullscreen. Gamepads are supported. Keys 1–6 also trigger the abilities.

## Files
- `scripts/main.gd`: abilities, flow meter, scoring, zones
- `scripts/world.gd`: map generation
- `scripts/player.gd`: movement
- `scripts/camera_rig.gd`: camera
- `scripts/hud.gd`: UI
- `scripts/audio.gd`: generated music and sound
- `scripts/fx.gd`: particles

You can tune the cooldowns and durations in the `ABILITIES` list at the top of `main.gd`.

## Tracks (v3)
Choose a starting track on the menu with A/D or the arrow buttons. After that, the town changes every 750 m and the new town arrives from the horizon.

| # | Track | Look |
|---|---|---|
| 1 | Sky Roads | the original neon sky-road over a sea of clouds |
| 2 | Lantern Festival | pastel shophouses, strings of red lanterns overhead, market stalls, people, confetti, a skyline with a needle tower |
| 3 | Skate Park | sunny plaza, graffiti half-pipes, trees, pennant flags, roller-coaster arches |
| 4 | Neon Rain Alley | night, rain, wet reflective street (reflections need the Forward+ renderer), neon signs, glowing lanterns, a pagoda on misty peaks |
| 5 | Neon Market | stacked cartoon buildings, neon panels, AC units, power lines, a glowing pink bike lane |
| 6 | Hover Harbor | golden-hour sky city with floating platforms, cranes, beacon pillars and hover pods |
| 7 | Sakura Heights | cherry trees, torii gates, stone lanterns, timber houses, falling petals, snowy mountains |
| 8 | Candy Carnival | striped tents, giant lollipops, balloons, light-bulb strings, Ferris wheels |

Night towns place real point lights at their signs, lanterns and lamps. A soft light also follows the fox in dark zones.

**Warp tunnels** sit over one side lane only, so entering is your choice. An on-screen marker shows where each one goes ("WARP TO …"). Switch into that lane to warp to that town (+300 points), or stay in the other lanes to keep running.

All the town models live in `scripts/themes.gd`.

## v4 changes
- **Fair paths:** every row has a guaranteed clear lane. It is either empty or needs just a jump or a slide, and it never moves more than one lane from the previous row's clear lane. A **gold coin trail** leads you into it: arcs mean jump, low coins mean slide, and coins on a rail mean grind. Drones never patrol into the clear lane. A bot that only follows the coins ran through all 8 towns without dying.
- **More forgiving:**
  - smaller hitboxes
  - short grace periods after wall runs, grapples and warps
  - clipping the side of an obstacle makes you stumble instead of crashing
  - no ground obstacles under the sky highways
- **Revive:** when you crash with enough gold, press **R** (or click the button) to continue. It costs 100 gold, and the cost doubles each time.
- **Skate Park:**
  - grab the floating **skateboard** (30 s). You ride faster, and your first crash only breaks the board
  - jump onto **metal rails** to **grind**, with sparks and bonus points
  - hit **launch ramps** for big air (a kickflip bonus on the board)
  - the side walls turn into graffiti skate walls for wall rides
- **Pop-up traps** (Lantern Festival, Neon Rain, Neon Market, Hover Harbor, Sakura, Carnival): barriers and spike strips rise out of the road, and crates drop from the sky. Flashing red chevrons, or a red circle for drops, show exactly where each trap will appear. Traps are never placed in the coin lane.

## v5: characters and shared animations
On the menu, press **Q / E** (or click the arrows) to pick a runner. Mixamo characters wait in a **lobby** doing their hobby. Your pick is saved.

| Runner | Model file | Lobby hobby and props |
|---|---|---|
| FOX | built-in | jogs the track preview |
| HOOPS | Medium_Run.fbx | dribbling, with a bouncing ball. Uses the lean clip until **Dribble.fbx** is added |
| ROCKY | Punching_Bag.fbx | punching bag on a frame |
| PIXEL | Gaming.fbx | bean bag, TV and console |
| ACE | Golf_Drive.fbx | golf drive / bad shot (alternating), club in hand, ball on a tee |
| CHILL | Leaning_On_A_Wall.fbx | leaning on a brick wall, glowing headphones |

**How the retargeting works:** all the FBX files use the same Mixamo skeleton (65 bones). `tools/bake_animations.gd` pulls every clip into one shared library, `characters/animations.res`. It removes the forward drift so runs stay in place and sets which clips loop. Each character then loads that library and scales the hip height to its own skeleton, so **every runner plays every animation**.

**In-game clips:**

| When | Clip |
|---|---|
| Running (speeds up with the game) | Medium Run |
| Lane changes | Running Arc / Running Arc 1 |
| Jump | Running Jump |
| Double jump | Jump 1 |
| Slide | Running Slide |
| Dash | Soccer Tackle, played fast (a slide-tackle through crates) |
| Air dash, slam, riding the skateboard | Dash pose |
| Stumble | first part of Sweep Fall |
| Crash | Fall Flat |

### Adding more
- **New clips** (Dribble.fbx, Run_Forward.fbx and so on): put the FBX in `characters/source/` and run
  `godot --headless -s res://tools/bake_animations.gd`
  Dribble becomes HOOPS's hobby automatically. Run_Forward is baked as `run_fast`, but the game doesn't use it yet. To add a new clip name, edit `NAMES` in the bake script.
- **Textures:** the FBX files only *link* to their colour images, which weren't included, so every runner currently shows a flat placeholder colour. Put each image in `characters/textures/` named after the runner:
  `hoops.jpg`, `rocky.jpg`, `pixel.jpg`, `ace.jpg`, `chill.jpg` (.png also works). They are applied automatically.
  Original names: HOOPS = *stylized boy 3d model_basecolor*, ACE = *stylized game character 3d model_basecolor*, and ROCKY, PIXEL and CHILL were each exported as *stylized character 3d model_basecolor* (three different images with the same name).
- **New characters:** add an entry to `CHARACTERS` in `characters/character_rig.gd` with its FBX, hobby clip(s), texture name and prop.
